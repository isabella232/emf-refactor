package PAM.diagram.application;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

/**
 * @generated NOT
 */
public class DiagramEditorPerspective implements IPerspectiveFactory {
	/**
	 * @generated
	 */
	public void createInitialLayout(IPageLayout layout) {
		IFolderLayout bottom = layout.createFolder(
				"bottom", IPageLayout.BOTTOM, 0.7f, layout.getEditorArea()); //$NON-NLS-1$	 //$NON-NLS-2$
		bottom.addView(IPageLayout.ID_PROP_SHEET);
		bottom.addView("pam.metrics.views.Metrics");
		bottom.addView("pam.monitor.views.Monitor");
	}
}
