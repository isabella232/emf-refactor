package PAM.diagram.edit.helpers;

/**
 * @generated
 */
public class CoolingEditHelper extends PAMBaseEditHelper {
}
