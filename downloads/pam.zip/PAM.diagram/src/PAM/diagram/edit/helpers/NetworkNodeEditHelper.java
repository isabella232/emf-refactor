package PAM.diagram.edit.helpers;

/**
 * @generated
 */
public class NetworkNodeEditHelper extends PAMBaseEditHelper {
}
