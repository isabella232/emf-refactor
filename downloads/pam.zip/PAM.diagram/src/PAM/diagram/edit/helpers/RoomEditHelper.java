package PAM.diagram.edit.helpers;

/**
 * @generated
 */
public class RoomEditHelper extends PAMBaseEditHelper {
}
