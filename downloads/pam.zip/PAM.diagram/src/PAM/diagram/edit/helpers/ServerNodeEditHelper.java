package PAM.diagram.edit.helpers;

/**
 * @generated
 */
public class ServerNodeEditHelper extends PAMBaseEditHelper {
}
