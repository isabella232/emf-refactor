package PAM.diagram.edit.helpers;

/**
 * @generated
 */
public class UninterruptiblePowerSupplyEditHelper extends PAMBaseEditHelper {
}
