package PAM.diagram.edit.parts;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.draw2d.GridData;
import org.eclipse.draw2d.GridLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

import PAM.diagram.edit.policies.ClientNodeItemSemanticEditPolicy;
import PAM.diagram.part.PAMVisualIDRegistry;
import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class ClientNodeEditPart extends ShapeNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 2009;

	/**
	 * @generated
	 */
	protected IFigure contentPane;

	/**
	 * @generated
	 */
	protected IFigure primaryShape;

	/**
	 * @generated
	 */
	public ClientNodeEditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new ClientNodeItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		// XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	 * @generated
	 */
	protected LayoutEditPolicy createLayoutEditPolicy() {
		org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy lep = new org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy() {

			protected EditPolicy createChildEditPolicy(EditPart child) {
				EditPolicy result = child
						.getEditPolicy(EditPolicy.PRIMARY_DRAG_ROLE);
				if (result == null) {
					result = new NonResizableEditPolicy();
				}
				return result;
			}

			protected Command getMoveChildrenCommand(Request request) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	 * @generated
	 */
	protected IFigure createNodeShape() {
		return primaryShape = new ClientNodeFigure();
	}

	/**
	 * @generated
	 */
	public ClientNodeFigure getPrimaryShape() {
		return (ClientNodeFigure) primaryShape;
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof ClientNodeNameEditPart) {
			((ClientNodeNameEditPart) childEditPart).setLabel(getPrimaryShape()
					.getFigureClientNodeName());
			return true;
		}
		if (childEditPart instanceof ClientNodeMax_WattEditPart) {
			((ClientNodeMax_WattEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureClientNodeMax_Watt());
			return true;
		}
		if (childEditPart instanceof ClientNodeMFLOPsEditPart) {
			((ClientNodeMFLOPsEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureClientNodeMFLOPS());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof ClientNodeNameEditPart) {
			return true;
		}
		if (childEditPart instanceof ClientNodeMax_WattEditPart) {
			return true;
		}
		if (childEditPart instanceof ClientNodeMFLOPsEditPart) {
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * @generated
	 */
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	 * @generated
	 */
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		return getContentPane();
	}

	/**
	 * @generated
	 */
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(40, 40);
		return result;
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	 * Default implementation treats passed figure as content pane.
	 * Respects layout one may have set for generated figure.
	 * @param nodeShape instance of generated figure class
	 * @generated
	 */
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	 * @generated
	 */
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	 * @generated
	 */
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	 * @generated
	 */
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(PAMVisualIDRegistry
				.getType(ClientNodeNameEditPart.VISUAL_ID));
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSource() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				1);
		types.add(PAMElementTypes.NetworkObjectLink_4002);
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSourceAndTarget(
			IGraphicalEditPart targetEditPart) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (targetEditPart instanceof NetworkNodeEditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		if (targetEditPart instanceof NetworkNode2EditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMATypesForTarget(
			IElementType relationshipType) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (relationshipType == PAMElementTypes.NetworkObjectLink_4002) {
			types.add(PAMElementTypes.NetworkNode_2007);
			types.add(PAMElementTypes.NetworkNode_3009);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public class ClientNodeFigure extends RoundedRectangle {

		/**
		 * @generated
		 */
		private WrappingLabel fFigureClientNodeName;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureClientNodeMax_Watt;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureClientNodeMFLOPS;

		/**
		 * @generated
		 */
		public ClientNodeFigure() {

			GridLayout layoutThis = new GridLayout();
			layoutThis.numColumns = 1;
			layoutThis.makeColumnsEqualWidth = true;
			layoutThis.horizontalSpacing = 5;
			layoutThis.verticalSpacing = 5;
			layoutThis.marginWidth = 5;
			layoutThis.marginHeight = 5;
			this.setLayoutManager(layoutThis);

			this.setCornerDimensions(new Dimension(getMapMode().DPtoLP(8),
					getMapMode().DPtoLP(8)));
			this.setFill(false);
			this.setLineWidth(3);
			this.setForegroundColor(THIS_FORE);
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			WrappingLabel clientNodeStereotype0 = new WrappingLabel();
			clientNodeStereotype0.setText("<<Client>>");

			GridData constraintClientNodeStereotype0 = new GridData();
			constraintClientNodeStereotype0.verticalAlignment = GridData.CENTER;
			constraintClientNodeStereotype0.horizontalAlignment = GridData.CENTER;
			constraintClientNodeStereotype0.horizontalIndent = 0;
			constraintClientNodeStereotype0.horizontalSpan = 1;
			constraintClientNodeStereotype0.verticalSpan = 1;
			constraintClientNodeStereotype0.grabExcessHorizontalSpace = true;
			constraintClientNodeStereotype0.grabExcessVerticalSpace = false;
			this.add(clientNodeStereotype0, constraintClientNodeStereotype0);

			fFigureClientNodeName = new WrappingLabel();
			fFigureClientNodeName.setText("<...>");

			GridData constraintFFigureClientNodeName = new GridData();
			constraintFFigureClientNodeName.verticalAlignment = GridData.CENTER;
			constraintFFigureClientNodeName.horizontalAlignment = GridData.CENTER;
			constraintFFigureClientNodeName.horizontalIndent = 0;
			constraintFFigureClientNodeName.horizontalSpan = 1;
			constraintFFigureClientNodeName.verticalSpan = 1;
			constraintFFigureClientNodeName.grabExcessHorizontalSpace = true;
			constraintFFigureClientNodeName.grabExcessVerticalSpace = false;
			this.add(fFigureClientNodeName, constraintFFigureClientNodeName);

			RectangleFigure separator0 = new RectangleFigure();
			separator0.setFill(false);
			separator0.setLineWidth(3);
			separator0.setPreferredSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));
			separator0.setMaximumSize(new Dimension(getMapMode().DPtoLP(3000),
					getMapMode().DPtoLP(6)));
			separator0.setMinimumSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));

			GridData constraintSeparator0 = new GridData();
			constraintSeparator0.verticalAlignment = GridData.FILL;
			constraintSeparator0.horizontalAlignment = GridData.FILL;
			constraintSeparator0.horizontalIndent = 0;
			constraintSeparator0.horizontalSpan = 1;
			constraintSeparator0.verticalSpan = 1;
			constraintSeparator0.grabExcessHorizontalSpace = true;
			constraintSeparator0.grabExcessVerticalSpace = false;
			constraintSeparator0.widthHint = 1;
			constraintSeparator0.heightHint = 1;
			this.add(separator0, constraintSeparator0);

			fFigureClientNodeMax_Watt = new WrappingLabel();
			fFigureClientNodeMax_Watt.setText("<...>");

			GridData constraintFFigureClientNodeMax_Watt = new GridData();
			constraintFFigureClientNodeMax_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureClientNodeMax_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureClientNodeMax_Watt.horizontalIndent = 0;
			constraintFFigureClientNodeMax_Watt.horizontalSpan = 1;
			constraintFFigureClientNodeMax_Watt.verticalSpan = 1;
			constraintFFigureClientNodeMax_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureClientNodeMax_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureClientNodeMax_Watt,
					constraintFFigureClientNodeMax_Watt);

			fFigureClientNodeMFLOPS = new WrappingLabel();
			fFigureClientNodeMFLOPS.setText("<...>");

			GridData constraintFFigureClientNodeMFLOPS = new GridData();
			constraintFFigureClientNodeMFLOPS.verticalAlignment = GridData.CENTER;
			constraintFFigureClientNodeMFLOPS.horizontalAlignment = GridData.CENTER;
			constraintFFigureClientNodeMFLOPS.horizontalIndent = 0;
			constraintFFigureClientNodeMFLOPS.horizontalSpan = 1;
			constraintFFigureClientNodeMFLOPS.verticalSpan = 1;
			constraintFFigureClientNodeMFLOPS.grabExcessHorizontalSpace = true;
			constraintFFigureClientNodeMFLOPS.grabExcessVerticalSpace = false;
			this.add(fFigureClientNodeMFLOPS, constraintFFigureClientNodeMFLOPS);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureClientNodeName() {
			return fFigureClientNodeName;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureClientNodeMax_Watt() {
			return fFigureClientNodeMax_Watt;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureClientNodeMFLOPS() {
			return fFigureClientNodeMFLOPS;
		}

	}

	/**
	 * @generated
	 */
	static final Color THIS_FORE = new Color(null, 0, 0, 0);

}
