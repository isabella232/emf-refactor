package PAM.diagram.edit.parts;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.draw2d.GridData;
import org.eclipse.draw2d.GridLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

import PAM.diagram.edit.policies.NetworkNode2ItemSemanticEditPolicy;
import PAM.diagram.part.PAMVisualIDRegistry;
import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class NetworkNode2EditPart extends ShapeNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 3009;

	/**
	 * @generated
	 */
	protected IFigure contentPane;

	/**
	 * @generated
	 */
	protected IFigure primaryShape;

	/**
	 * @generated
	 */
	public NetworkNode2EditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new NetworkNode2ItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		// XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	 * @generated
	 */
	protected LayoutEditPolicy createLayoutEditPolicy() {
		org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy lep = new org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy() {

			protected EditPolicy createChildEditPolicy(EditPart child) {
				EditPolicy result = child
						.getEditPolicy(EditPolicy.PRIMARY_DRAG_ROLE);
				if (result == null) {
					result = new NonResizableEditPolicy();
				}
				return result;
			}

			protected Command getMoveChildrenCommand(Request request) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	 * @generated
	 */
	protected IFigure createNodeShape() {
		return primaryShape = new NetworkNodeFigure();
	}

	/**
	 * @generated
	 */
	public NetworkNodeFigure getPrimaryShape() {
		return (NetworkNodeFigure) primaryShape;
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof NetworkNodeName2EditPart) {
			((NetworkNodeName2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureNetworkNodeName());
			return true;
		}
		if (childEditPart instanceof NetworkNodeMax_Watt2EditPart) {
			((NetworkNodeMax_Watt2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureNetworkNodeMax_Watt());
			return true;
		}
		if (childEditPart instanceof NetworkNodeMax_Throughput2EditPart) {
			((NetworkNodeMax_Throughput2EditPart) childEditPart)
					.setLabel(getPrimaryShape()
							.getFigureNetworkNodeMax_Throughput());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof NetworkNodeName2EditPart) {
			return true;
		}
		if (childEditPart instanceof NetworkNodeMax_Watt2EditPart) {
			return true;
		}
		if (childEditPart instanceof NetworkNodeMax_Throughput2EditPart) {
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * @generated
	 */
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	 * @generated
	 */
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		return getContentPane();
	}

	/**
	 * @generated
	 */
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(40, 40);
		return result;
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	 * Default implementation treats passed figure as content pane.
	 * Respects layout one may have set for generated figure.
	 * @param nodeShape instance of generated figure class
	 * @generated
	 */
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	 * @generated
	 */
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	 * @generated
	 */
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	 * @generated
	 */
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(PAMVisualIDRegistry
				.getType(NetworkNodeName2EditPart.VISUAL_ID));
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSource() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				1);
		types.add(PAMElementTypes.NetworkObjectLink_4002);
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSourceAndTarget(
			IGraphicalEditPart targetEditPart) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (targetEditPart instanceof NetworkNodeEditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		if (targetEditPart instanceof PAM.diagram.edit.parts.NetworkNode2EditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMATypesForTarget(
			IElementType relationshipType) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (relationshipType == PAMElementTypes.NetworkObjectLink_4002) {
			types.add(PAMElementTypes.NetworkNode_2007);
			types.add(PAMElementTypes.NetworkNode_3009);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnTarget() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				1);
		types.add(PAMElementTypes.NetworkObjectLink_4002);
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMATypesForSource(
			IElementType relationshipType) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (relationshipType == PAMElementTypes.NetworkObjectLink_4002) {
			types.add(PAMElementTypes.NetworkNode_2007);
			types.add(PAMElementTypes.ServerNode_2008);
			types.add(PAMElementTypes.ClientNode_2009);
			types.add(PAMElementTypes.ClientNode_3007);
			types.add(PAMElementTypes.ServerNode_3008);
			types.add(PAMElementTypes.NetworkNode_3009);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public class NetworkNodeFigure extends RoundedRectangle {

		/**
		 * @generated
		 */
		private WrappingLabel fFigureNetworkNodeName;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureNetworkNodeMax_Throughput;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureNetworkNodeMax_Watt;

		/**
		 * @generated
		 */
		public NetworkNodeFigure() {

			GridLayout layoutThis = new GridLayout();
			layoutThis.numColumns = 1;
			layoutThis.makeColumnsEqualWidth = true;
			layoutThis.horizontalSpacing = 5;
			layoutThis.verticalSpacing = 5;
			layoutThis.marginWidth = 5;
			layoutThis.marginHeight = 5;
			this.setLayoutManager(layoutThis);

			this.setCornerDimensions(new Dimension(getMapMode().DPtoLP(8),
					getMapMode().DPtoLP(8)));
			this.setFill(false);
			this.setLineWidth(3);
			this.setForegroundColor(THIS_FORE);
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			WrappingLabel networkNodeStereotype0 = new WrappingLabel();
			networkNodeStereotype0.setText("<<Network>>");

			GridData constraintNetworkNodeStereotype0 = new GridData();
			constraintNetworkNodeStereotype0.verticalAlignment = GridData.CENTER;
			constraintNetworkNodeStereotype0.horizontalAlignment = GridData.CENTER;
			constraintNetworkNodeStereotype0.horizontalIndent = 0;
			constraintNetworkNodeStereotype0.horizontalSpan = 1;
			constraintNetworkNodeStereotype0.verticalSpan = 1;
			constraintNetworkNodeStereotype0.grabExcessHorizontalSpace = true;
			constraintNetworkNodeStereotype0.grabExcessVerticalSpace = false;
			this.add(networkNodeStereotype0, constraintNetworkNodeStereotype0);

			fFigureNetworkNodeName = new WrappingLabel();
			fFigureNetworkNodeName.setText("<...>");

			GridData constraintFFigureNetworkNodeName = new GridData();
			constraintFFigureNetworkNodeName.verticalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeName.horizontalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeName.horizontalIndent = 0;
			constraintFFigureNetworkNodeName.horizontalSpan = 1;
			constraintFFigureNetworkNodeName.verticalSpan = 1;
			constraintFFigureNetworkNodeName.grabExcessHorizontalSpace = true;
			constraintFFigureNetworkNodeName.grabExcessVerticalSpace = false;
			this.add(fFigureNetworkNodeName, constraintFFigureNetworkNodeName);

			RectangleFigure separator0 = new RectangleFigure();
			separator0.setFill(false);
			separator0.setLineWidth(3);
			separator0.setPreferredSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));
			separator0.setMaximumSize(new Dimension(getMapMode().DPtoLP(3000),
					getMapMode().DPtoLP(6)));
			separator0.setMinimumSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));

			GridData constraintSeparator0 = new GridData();
			constraintSeparator0.verticalAlignment = GridData.FILL;
			constraintSeparator0.horizontalAlignment = GridData.FILL;
			constraintSeparator0.horizontalIndent = 0;
			constraintSeparator0.horizontalSpan = 1;
			constraintSeparator0.verticalSpan = 1;
			constraintSeparator0.grabExcessHorizontalSpace = true;
			constraintSeparator0.grabExcessVerticalSpace = false;
			constraintSeparator0.widthHint = 1;
			constraintSeparator0.heightHint = 1;
			this.add(separator0, constraintSeparator0);

			fFigureNetworkNodeMax_Watt = new WrappingLabel();
			fFigureNetworkNodeMax_Watt.setText("<...>");

			GridData constraintFFigureNetworkNodeMax_Watt = new GridData();
			constraintFFigureNetworkNodeMax_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeMax_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeMax_Watt.horizontalIndent = 0;
			constraintFFigureNetworkNodeMax_Watt.horizontalSpan = 1;
			constraintFFigureNetworkNodeMax_Watt.verticalSpan = 1;
			constraintFFigureNetworkNodeMax_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureNetworkNodeMax_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureNetworkNodeMax_Watt,
					constraintFFigureNetworkNodeMax_Watt);

			fFigureNetworkNodeMax_Throughput = new WrappingLabel();
			fFigureNetworkNodeMax_Throughput.setText("<...>");

			GridData constraintFFigureNetworkNodeMax_Throughput = new GridData();
			constraintFFigureNetworkNodeMax_Throughput.verticalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeMax_Throughput.horizontalAlignment = GridData.CENTER;
			constraintFFigureNetworkNodeMax_Throughput.horizontalIndent = 0;
			constraintFFigureNetworkNodeMax_Throughput.horizontalSpan = 1;
			constraintFFigureNetworkNodeMax_Throughput.verticalSpan = 1;
			constraintFFigureNetworkNodeMax_Throughput.grabExcessHorizontalSpace = true;
			constraintFFigureNetworkNodeMax_Throughput.grabExcessVerticalSpace = false;
			this.add(fFigureNetworkNodeMax_Throughput,
					constraintFFigureNetworkNodeMax_Throughput);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureNetworkNodeName() {
			return fFigureNetworkNodeName;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureNetworkNodeMax_Throughput() {
			return fFigureNetworkNodeMax_Throughput;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureNetworkNodeMax_Watt() {
			return fFigureNetworkNodeMax_Watt;
		}

	}

	/**
	 * @generated
	 */
	static final Color THIS_FORE = new Color(null, 0, 0, 0);

}
