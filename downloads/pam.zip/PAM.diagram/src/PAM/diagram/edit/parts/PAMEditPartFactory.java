package PAM.diagram.edit.parts;

import org.eclipse.draw2d.FigureUtilities;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;

import PAM.diagram.part.PAMVisualIDRegistry;

/**
 * @generated
 */
public class PAMEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (PAMVisualIDRegistry.getVisualID(view)) {

			case RoomEditPart.VISUAL_ID:
				return new RoomEditPart(view);

			case NetworkNodeEditPart.VISUAL_ID:
				return new NetworkNodeEditPart(view);

			case NetworkNodeNameEditPart.VISUAL_ID:
				return new NetworkNodeNameEditPart(view);

			case NetworkNodeMax_WattEditPart.VISUAL_ID:
				return new NetworkNodeMax_WattEditPart(view);

			case NetworkNodeMax_ThroughputEditPart.VISUAL_ID:
				return new NetworkNodeMax_ThroughputEditPart(view);

			case ServerNodeEditPart.VISUAL_ID:
				return new ServerNodeEditPart(view);

			case ServerNodeNameEditPart.VISUAL_ID:
				return new ServerNodeNameEditPart(view);

			case ServerNodeMax_WattEditPart.VISUAL_ID:
				return new ServerNodeMax_WattEditPart(view);

			case ServerNodeIdle_WattEditPart.VISUAL_ID:
				return new ServerNodeIdle_WattEditPart(view);

			case ServerNodeAct_WattEditPart.VISUAL_ID:
				return new ServerNodeAct_WattEditPart(view);

			case ServerNodeMax_CapacityEditPart.VISUAL_ID:
				return new ServerNodeMax_CapacityEditPart(view);

			case ServerNodeMFLOPsEditPart.VISUAL_ID:
				return new ServerNodeMFLOPsEditPart(view);

			case ClientNodeEditPart.VISUAL_ID:
				return new ClientNodeEditPart(view);

			case ClientNodeNameEditPart.VISUAL_ID:
				return new ClientNodeNameEditPart(view);

			case ClientNodeMax_WattEditPart.VISUAL_ID:
				return new ClientNodeMax_WattEditPart(view);

			case ClientNodeMFLOPsEditPart.VISUAL_ID:
				return new ClientNodeMFLOPsEditPart(view);

			case Room2EditPart.VISUAL_ID:
				return new Room2EditPart(view);

			case RoomNameEditPart.VISUAL_ID:
				return new RoomNameEditPart(view);

			case CoolingEditPart.VISUAL_ID:
				return new CoolingEditPart(view);

			case CoolingNameEditPart.VISUAL_ID:
				return new CoolingNameEditPart(view);

			case CoolingMax_WattEditPart.VISUAL_ID:
				return new CoolingMax_WattEditPart(view);

			case CoolingCooling_CapacityEditPart.VISUAL_ID:
				return new CoolingCooling_CapacityEditPart(view);

			case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyEditPart(view);

			case UninterruptiblePowerSupplyNameEditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyNameEditPart(view);

			case UninterruptiblePowerSupplyOut_WattEditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyOut_WattEditPart(view);

			case UninterruptiblePowerSupplyEfficiencyEditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyEfficiencyEditPart(view);

			case ClientNode2EditPart.VISUAL_ID:
				return new ClientNode2EditPart(view);

			case ClientNodeName2EditPart.VISUAL_ID:
				return new ClientNodeName2EditPart(view);

			case ClientNodeMax_Watt2EditPart.VISUAL_ID:
				return new ClientNodeMax_Watt2EditPart(view);

			case ClientNodeMFLOPs2EditPart.VISUAL_ID:
				return new ClientNodeMFLOPs2EditPart(view);

			case ServerNode2EditPart.VISUAL_ID:
				return new ServerNode2EditPart(view);

			case ServerNodeName2EditPart.VISUAL_ID:
				return new ServerNodeName2EditPart(view);

			case ServerNodeMax_Watt2EditPart.VISUAL_ID:
				return new ServerNodeMax_Watt2EditPart(view);

			case ServerNodeIdle_Watt2EditPart.VISUAL_ID:
				return new ServerNodeIdle_Watt2EditPart(view);

			case ServerNodeAct_Watt2EditPart.VISUAL_ID:
				return new ServerNodeAct_Watt2EditPart(view);

			case ServerNodeMax_Capacity2EditPart.VISUAL_ID:
				return new ServerNodeMax_Capacity2EditPart(view);

			case ServerNodeMFLOPs2EditPart.VISUAL_ID:
				return new ServerNodeMFLOPs2EditPart(view);

			case NetworkNode2EditPart.VISUAL_ID:
				return new NetworkNode2EditPart(view);

			case NetworkNodeName2EditPart.VISUAL_ID:
				return new NetworkNodeName2EditPart(view);

			case NetworkNodeMax_Watt2EditPart.VISUAL_ID:
				return new NetworkNodeMax_Watt2EditPart(view);

			case NetworkNodeMax_Throughput2EditPart.VISUAL_ID:
				return new NetworkNodeMax_Throughput2EditPart(view);

			case Cooling2EditPart.VISUAL_ID:
				return new Cooling2EditPart(view);

			case CoolingName2EditPart.VISUAL_ID:
				return new CoolingName2EditPart(view);

			case CoolingMax_Watt2EditPart.VISUAL_ID:
				return new CoolingMax_Watt2EditPart(view);

			case CoolingCooling_Capacity2EditPart.VISUAL_ID:
				return new CoolingCooling_Capacity2EditPart(view);

			case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
				return new UninterruptiblePowerSupply2EditPart(view);

			case UninterruptiblePowerSupplyName2EditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyName2EditPart(view);

			case UninterruptiblePowerSupplyOut_Watt2EditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyOut_Watt2EditPart(view);

			case UninterruptiblePowerSupplyEfficiency2EditPart.VISUAL_ID:
				return new UninterruptiblePowerSupplyEfficiency2EditPart(view);

			case Room3EditPart.VISUAL_ID:
				return new Room3EditPart(view);

			case RoomName2EditPart.VISUAL_ID:
				return new RoomName2EditPart(view);

			case RoomRoomCompartmentEditPart.VISUAL_ID:
				return new RoomRoomCompartmentEditPart(view);

			case RoomRoomCompartment2EditPart.VISUAL_ID:
				return new RoomRoomCompartment2EditPart(view);

			case NetworkObjectLinkEditPart.VISUAL_ID:
				return new NetworkObjectLinkEditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		if (source.getFigure() instanceof WrappingLabel)
			return new TextCellEditorLocator((WrappingLabel) source.getFigure());
		else {
			return new LabelCellEditorLocator((Label) source.getFigure());
		}
	}

	/**
	 * @generated
	 */
	static private class TextCellEditorLocator implements CellEditorLocator {

		/**
		 * @generated
		 */
		private WrappingLabel wrapLabel;

		/**
		 * @generated
		 */
		public TextCellEditorLocator(WrappingLabel wrapLabel) {
			this.wrapLabel = wrapLabel;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getWrapLabel() {
			return wrapLabel;
		}

		/**
		 * @generated
		 */
		public void relocate(CellEditor celleditor) {
			Text text = (Text) celleditor.getControl();
			Rectangle rect = getWrapLabel().getTextBounds().getCopy();
			getWrapLabel().translateToAbsolute(rect);
			if (!text.getFont().isDisposed()) {
				if (getWrapLabel().isTextWrapOn()
						&& getWrapLabel().getText().length() > 0) {
					rect.setSize(new Dimension(text.computeSize(rect.width,
							SWT.DEFAULT)));
				} else {
					int avr = FigureUtilities.getFontMetrics(text.getFont())
							.getAverageCharWidth();
					rect.setSize(new Dimension(text.computeSize(SWT.DEFAULT,
							SWT.DEFAULT)).expand(avr * 2, 0));
				}
			}
			if (!rect.equals(new Rectangle(text.getBounds()))) {
				text.setBounds(rect.x, rect.y, rect.width, rect.height);
			}
		}
	}

	/**
	 * @generated
	 */
	private static class LabelCellEditorLocator implements CellEditorLocator {

		/**
		 * @generated
		 */
		private Label label;

		/**
		 * @generated
		 */
		public LabelCellEditorLocator(Label label) {
			this.label = label;
		}

		/**
		 * @generated
		 */
		public Label getLabel() {
			return label;
		}

		/**
		 * @generated
		 */
		public void relocate(CellEditor celleditor) {
			Text text = (Text) celleditor.getControl();
			Rectangle rect = getLabel().getTextBounds().getCopy();
			getLabel().translateToAbsolute(rect);
			if (!text.getFont().isDisposed()) {
				int avr = FigureUtilities.getFontMetrics(text.getFont())
						.getAverageCharWidth();
				rect.setSize(new Dimension(text.computeSize(SWT.DEFAULT,
						SWT.DEFAULT)).expand(avr * 2, 0));
			}
			if (!rect.equals(new Rectangle(text.getBounds()))) {
				text.setBounds(rect.x, rect.y, rect.width, rect.height);
			}
		}
	}
}
