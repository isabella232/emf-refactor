package PAM.diagram.edit.parts;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.draw2d.GridData;
import org.eclipse.draw2d.GridLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

import PAM.diagram.edit.policies.ServerNode2ItemSemanticEditPolicy;
import PAM.diagram.part.PAMVisualIDRegistry;
import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class ServerNode2EditPart extends ShapeNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 3008;

	/**
	 * @generated
	 */
	protected IFigure contentPane;

	/**
	 * @generated
	 */
	protected IFigure primaryShape;

	/**
	 * @generated
	 */
	public ServerNode2EditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new ServerNode2ItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		// XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	 * @generated
	 */
	protected LayoutEditPolicy createLayoutEditPolicy() {
		org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy lep = new org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy() {

			protected EditPolicy createChildEditPolicy(EditPart child) {
				EditPolicy result = child
						.getEditPolicy(EditPolicy.PRIMARY_DRAG_ROLE);
				if (result == null) {
					result = new NonResizableEditPolicy();
				}
				return result;
			}

			protected Command getMoveChildrenCommand(Request request) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	 * @generated
	 */
	protected IFigure createNodeShape() {
		return primaryShape = new ServerNodeFigure();
	}

	/**
	 * @generated
	 */
	public ServerNodeFigure getPrimaryShape() {
		return (ServerNodeFigure) primaryShape;
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof ServerNodeName2EditPart) {
			((ServerNodeName2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureServerNodeName());
			return true;
		}
		if (childEditPart instanceof ServerNodeMax_Watt2EditPart) {
			((ServerNodeMax_Watt2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureServerNodeMax_Watt());
			return true;
		}
		if (childEditPart instanceof ServerNodeIdle_Watt2EditPart) {
			((ServerNodeIdle_Watt2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureServerNodeIdle_Watt());
			return true;
		}
		if (childEditPart instanceof ServerNodeAct_Watt2EditPart) {
			((ServerNodeAct_Watt2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureServerNodeAct_Watt());
			return true;
		}
		if (childEditPart instanceof ServerNodeMax_Capacity2EditPart) {
			((ServerNodeMax_Capacity2EditPart) childEditPart)
					.setLabel(getPrimaryShape()
							.getFigureServerNodeMax_Capacity());
			return true;
		}
		if (childEditPart instanceof ServerNodeMFLOPs2EditPart) {
			((ServerNodeMFLOPs2EditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureServerNodeMFLOPS());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof ServerNodeName2EditPart) {
			return true;
		}
		if (childEditPart instanceof ServerNodeMax_Watt2EditPart) {
			return true;
		}
		if (childEditPart instanceof ServerNodeIdle_Watt2EditPart) {
			return true;
		}
		if (childEditPart instanceof ServerNodeAct_Watt2EditPart) {
			return true;
		}
		if (childEditPart instanceof ServerNodeMax_Capacity2EditPart) {
			return true;
		}
		if (childEditPart instanceof ServerNodeMFLOPs2EditPart) {
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * @generated
	 */
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	 * @generated
	 */
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		return getContentPane();
	}

	/**
	 * @generated
	 */
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(40, 40);
		return result;
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	 * Default implementation treats passed figure as content pane.
	 * Respects layout one may have set for generated figure.
	 * @param nodeShape instance of generated figure class
	 * @generated
	 */
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	 * @generated
	 */
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	 * @generated
	 */
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	 * @generated
	 */
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(PAMVisualIDRegistry
				.getType(ServerNodeName2EditPart.VISUAL_ID));
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSource() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				1);
		types.add(PAMElementTypes.NetworkObjectLink_4002);
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMARelTypesOnSourceAndTarget(
			IGraphicalEditPart targetEditPart) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (targetEditPart instanceof NetworkNodeEditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		if (targetEditPart instanceof NetworkNode2EditPart) {
			types.add(PAMElementTypes.NetworkObjectLink_4002);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/getMATypesForTarget(
			IElementType relationshipType) {
		LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new LinkedList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
		if (relationshipType == PAMElementTypes.NetworkObjectLink_4002) {
			types.add(PAMElementTypes.NetworkNode_2007);
			types.add(PAMElementTypes.NetworkNode_3009);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public class ServerNodeFigure extends RoundedRectangle {

		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeName;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeMax_Watt;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeIdle_Watt;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeAct_Watt;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeMax_Capacity;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureServerNodeMFLOPS;

		/**
		 * @generated
		 */
		public ServerNodeFigure() {

			GridLayout layoutThis = new GridLayout();
			layoutThis.numColumns = 1;
			layoutThis.makeColumnsEqualWidth = true;
			layoutThis.horizontalSpacing = 5;
			layoutThis.verticalSpacing = 5;
			layoutThis.marginWidth = 5;
			layoutThis.marginHeight = 5;
			this.setLayoutManager(layoutThis);

			this.setCornerDimensions(new Dimension(getMapMode().DPtoLP(8),
					getMapMode().DPtoLP(8)));
			this.setFill(false);
			this.setLineWidth(3);
			this.setForegroundColor(THIS_FORE);
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			WrappingLabel serverNodeStereotype0 = new WrappingLabel();
			serverNodeStereotype0.setText("<<Server>>");

			GridData constraintServerNodeStereotype0 = new GridData();
			constraintServerNodeStereotype0.verticalAlignment = GridData.CENTER;
			constraintServerNodeStereotype0.horizontalAlignment = GridData.CENTER;
			constraintServerNodeStereotype0.horizontalIndent = 0;
			constraintServerNodeStereotype0.horizontalSpan = 1;
			constraintServerNodeStereotype0.verticalSpan = 1;
			constraintServerNodeStereotype0.grabExcessHorizontalSpace = true;
			constraintServerNodeStereotype0.grabExcessVerticalSpace = false;
			this.add(serverNodeStereotype0, constraintServerNodeStereotype0);

			fFigureServerNodeName = new WrappingLabel();
			fFigureServerNodeName.setText("<...>");

			GridData constraintFFigureServerNodeName = new GridData();
			constraintFFigureServerNodeName.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeName.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeName.horizontalIndent = 0;
			constraintFFigureServerNodeName.horizontalSpan = 1;
			constraintFFigureServerNodeName.verticalSpan = 1;
			constraintFFigureServerNodeName.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeName.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeName, constraintFFigureServerNodeName);

			RectangleFigure separator0 = new RectangleFigure();
			separator0.setFill(false);
			separator0.setLineWidth(3);
			separator0.setPreferredSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));
			separator0.setMaximumSize(new Dimension(getMapMode().DPtoLP(3000),
					getMapMode().DPtoLP(6)));
			separator0.setMinimumSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));

			GridData constraintSeparator0 = new GridData();
			constraintSeparator0.verticalAlignment = GridData.FILL;
			constraintSeparator0.horizontalAlignment = GridData.FILL;
			constraintSeparator0.horizontalIndent = 0;
			constraintSeparator0.horizontalSpan = 1;
			constraintSeparator0.verticalSpan = 1;
			constraintSeparator0.grabExcessHorizontalSpace = true;
			constraintSeparator0.grabExcessVerticalSpace = false;
			constraintSeparator0.widthHint = 1;
			constraintSeparator0.heightHint = 1;
			this.add(separator0, constraintSeparator0);

			fFigureServerNodeMax_Watt = new WrappingLabel();
			fFigureServerNodeMax_Watt.setText("<...>");

			GridData constraintFFigureServerNodeMax_Watt = new GridData();
			constraintFFigureServerNodeMax_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMax_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMax_Watt.horizontalIndent = 0;
			constraintFFigureServerNodeMax_Watt.horizontalSpan = 1;
			constraintFFigureServerNodeMax_Watt.verticalSpan = 1;
			constraintFFigureServerNodeMax_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeMax_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeMax_Watt,
					constraintFFigureServerNodeMax_Watt);

			fFigureServerNodeIdle_Watt = new WrappingLabel();
			fFigureServerNodeIdle_Watt.setText("<...>");

			GridData constraintFFigureServerNodeIdle_Watt = new GridData();
			constraintFFigureServerNodeIdle_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeIdle_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeIdle_Watt.horizontalIndent = 0;
			constraintFFigureServerNodeIdle_Watt.horizontalSpan = 1;
			constraintFFigureServerNodeIdle_Watt.verticalSpan = 1;
			constraintFFigureServerNodeIdle_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeIdle_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeIdle_Watt,
					constraintFFigureServerNodeIdle_Watt);

			fFigureServerNodeAct_Watt = new WrappingLabel();
			fFigureServerNodeAct_Watt.setText("<...>");

			GridData constraintFFigureServerNodeAct_Watt = new GridData();
			constraintFFigureServerNodeAct_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeAct_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeAct_Watt.horizontalIndent = 0;
			constraintFFigureServerNodeAct_Watt.horizontalSpan = 1;
			constraintFFigureServerNodeAct_Watt.verticalSpan = 1;
			constraintFFigureServerNodeAct_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeAct_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeAct_Watt,
					constraintFFigureServerNodeAct_Watt);

			fFigureServerNodeMax_Capacity = new WrappingLabel();
			fFigureServerNodeMax_Capacity.setText("<...>");

			GridData constraintFFigureServerNodeMax_Capacity = new GridData();
			constraintFFigureServerNodeMax_Capacity.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMax_Capacity.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMax_Capacity.horizontalIndent = 0;
			constraintFFigureServerNodeMax_Capacity.horizontalSpan = 1;
			constraintFFigureServerNodeMax_Capacity.verticalSpan = 1;
			constraintFFigureServerNodeMax_Capacity.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeMax_Capacity.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeMax_Capacity,
					constraintFFigureServerNodeMax_Capacity);

			fFigureServerNodeMFLOPS = new WrappingLabel();
			fFigureServerNodeMFLOPS.setText("<...>");

			GridData constraintFFigureServerNodeMFLOPS = new GridData();
			constraintFFigureServerNodeMFLOPS.verticalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMFLOPS.horizontalAlignment = GridData.CENTER;
			constraintFFigureServerNodeMFLOPS.horizontalIndent = 0;
			constraintFFigureServerNodeMFLOPS.horizontalSpan = 1;
			constraintFFigureServerNodeMFLOPS.verticalSpan = 1;
			constraintFFigureServerNodeMFLOPS.grabExcessHorizontalSpace = true;
			constraintFFigureServerNodeMFLOPS.grabExcessVerticalSpace = false;
			this.add(fFigureServerNodeMFLOPS, constraintFFigureServerNodeMFLOPS);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeName() {
			return fFigureServerNodeName;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeMax_Watt() {
			return fFigureServerNodeMax_Watt;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeIdle_Watt() {
			return fFigureServerNodeIdle_Watt;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeAct_Watt() {
			return fFigureServerNodeAct_Watt;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeMax_Capacity() {
			return fFigureServerNodeMax_Capacity;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureServerNodeMFLOPS() {
			return fFigureServerNodeMFLOPS;
		}

	}

	/**
	 * @generated
	 */
	static final Color THIS_FORE = new Color(null, 0, 0, 0);

}
