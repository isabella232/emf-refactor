package PAM.diagram.edit.parts;

import org.eclipse.draw2d.GridData;
import org.eclipse.draw2d.GridLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RectangleFigure;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

import PAM.diagram.edit.policies.UninterruptiblePowerSupplyItemSemanticEditPolicy;
import PAM.diagram.part.PAMVisualIDRegistry;

/**
 * @generated
 */
public class UninterruptiblePowerSupplyEditPart extends ShapeNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 2012;

	/**
	 * @generated
	 */
	protected IFigure contentPane;

	/**
	 * @generated
	 */
	protected IFigure primaryShape;

	/**
	 * @generated
	 */
	public UninterruptiblePowerSupplyEditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(EditPolicyRoles.SEMANTIC_ROLE,
				new UninterruptiblePowerSupplyItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		// XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	 * @generated
	 */
	protected LayoutEditPolicy createLayoutEditPolicy() {
		org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy lep = new org.eclipse.gmf.runtime.diagram.ui.editpolicies.LayoutEditPolicy() {

			protected EditPolicy createChildEditPolicy(EditPart child) {
				EditPolicy result = child
						.getEditPolicy(EditPolicy.PRIMARY_DRAG_ROLE);
				if (result == null) {
					result = new NonResizableEditPolicy();
				}
				return result;
			}

			protected Command getMoveChildrenCommand(Request request) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	 * @generated
	 */
	protected IFigure createNodeShape() {
		return primaryShape = new UPSFigure();
	}

	/**
	 * @generated
	 */
	public UPSFigure getPrimaryShape() {
		return (UPSFigure) primaryShape;
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof UninterruptiblePowerSupplyNameEditPart) {
			((UninterruptiblePowerSupplyNameEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureUPSNameFigure());
			return true;
		}
		if (childEditPart instanceof UninterruptiblePowerSupplyOut_WattEditPart) {
			((UninterruptiblePowerSupplyOut_WattEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureUPSOut_Watt());
			return true;
		}
		if (childEditPart instanceof UninterruptiblePowerSupplyEfficiencyEditPart) {
			((UninterruptiblePowerSupplyEfficiencyEditPart) childEditPart)
					.setLabel(getPrimaryShape().getFigureUPSEfficiency());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof UninterruptiblePowerSupplyNameEditPart) {
			return true;
		}
		if (childEditPart instanceof UninterruptiblePowerSupplyOut_WattEditPart) {
			return true;
		}
		if (childEditPart instanceof UninterruptiblePowerSupplyEfficiencyEditPart) {
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * @generated
	 */
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	 * @generated
	 */
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		return getContentPane();
	}

	/**
	 * @generated
	 */
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(40, 40);
		return result;
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	 * Default implementation treats passed figure as content pane.
	 * Respects layout one may have set for generated figure.
	 * @param nodeShape instance of generated figure class
	 * @generated
	 */
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	 * @generated
	 */
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	 * @generated
	 */
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	 * @generated
	 */
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(PAMVisualIDRegistry
				.getType(UninterruptiblePowerSupplyNameEditPart.VISUAL_ID));
	}

	/**
	 * @generated
	 */
	public class UPSFigure extends RoundedRectangle {

		/**
		 * @generated
		 */
		private WrappingLabel fFigureUPSNameFigure;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureUPSOut_Watt;
		/**
		 * @generated
		 */
		private WrappingLabel fFigureUPSEfficiency;

		/**
		 * @generated
		 */
		public UPSFigure() {

			GridLayout layoutThis = new GridLayout();
			layoutThis.numColumns = 1;
			layoutThis.makeColumnsEqualWidth = true;
			layoutThis.horizontalSpacing = 5;
			layoutThis.verticalSpacing = 5;
			layoutThis.marginWidth = 5;
			layoutThis.marginHeight = 5;
			this.setLayoutManager(layoutThis);

			this.setCornerDimensions(new Dimension(getMapMode().DPtoLP(8),
					getMapMode().DPtoLP(8)));
			this.setFill(false);
			this.setLineWidth(3);
			this.setForegroundColor(THIS_FORE);
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			WrappingLabel uPSStereotype0 = new WrappingLabel();
			uPSStereotype0.setText("<<UPS>>");

			GridData constraintUPSStereotype0 = new GridData();
			constraintUPSStereotype0.verticalAlignment = GridData.CENTER;
			constraintUPSStereotype0.horizontalAlignment = GridData.CENTER;
			constraintUPSStereotype0.horizontalIndent = 0;
			constraintUPSStereotype0.horizontalSpan = 1;
			constraintUPSStereotype0.verticalSpan = 1;
			constraintUPSStereotype0.grabExcessHorizontalSpace = true;
			constraintUPSStereotype0.grabExcessVerticalSpace = false;
			this.add(uPSStereotype0, constraintUPSStereotype0);

			fFigureUPSNameFigure = new WrappingLabel();
			fFigureUPSNameFigure.setText("<...>");

			GridData constraintFFigureUPSNameFigure = new GridData();
			constraintFFigureUPSNameFigure.verticalAlignment = GridData.CENTER;
			constraintFFigureUPSNameFigure.horizontalAlignment = GridData.CENTER;
			constraintFFigureUPSNameFigure.horizontalIndent = 0;
			constraintFFigureUPSNameFigure.horizontalSpan = 1;
			constraintFFigureUPSNameFigure.verticalSpan = 1;
			constraintFFigureUPSNameFigure.grabExcessHorizontalSpace = true;
			constraintFFigureUPSNameFigure.grabExcessVerticalSpace = false;
			this.add(fFigureUPSNameFigure, constraintFFigureUPSNameFigure);

			RectangleFigure separator0 = new RectangleFigure();
			separator0.setFill(false);
			separator0.setLineWidth(3);
			separator0.setPreferredSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));
			separator0.setMaximumSize(new Dimension(getMapMode().DPtoLP(3000),
					getMapMode().DPtoLP(6)));
			separator0.setMinimumSize(new Dimension(getMapMode().DPtoLP(6),
					getMapMode().DPtoLP(6)));

			GridData constraintSeparator0 = new GridData();
			constraintSeparator0.verticalAlignment = GridData.FILL;
			constraintSeparator0.horizontalAlignment = GridData.FILL;
			constraintSeparator0.horizontalIndent = 0;
			constraintSeparator0.horizontalSpan = 1;
			constraintSeparator0.verticalSpan = 1;
			constraintSeparator0.grabExcessHorizontalSpace = true;
			constraintSeparator0.grabExcessVerticalSpace = false;
			constraintSeparator0.widthHint = 1;
			constraintSeparator0.heightHint = 1;
			this.add(separator0, constraintSeparator0);

			fFigureUPSOut_Watt = new WrappingLabel();
			fFigureUPSOut_Watt.setText("<...>");

			GridData constraintFFigureUPSOut_Watt = new GridData();
			constraintFFigureUPSOut_Watt.verticalAlignment = GridData.CENTER;
			constraintFFigureUPSOut_Watt.horizontalAlignment = GridData.CENTER;
			constraintFFigureUPSOut_Watt.horizontalIndent = 0;
			constraintFFigureUPSOut_Watt.horizontalSpan = 1;
			constraintFFigureUPSOut_Watt.verticalSpan = 1;
			constraintFFigureUPSOut_Watt.grabExcessHorizontalSpace = true;
			constraintFFigureUPSOut_Watt.grabExcessVerticalSpace = false;
			this.add(fFigureUPSOut_Watt, constraintFFigureUPSOut_Watt);

			fFigureUPSEfficiency = new WrappingLabel();
			fFigureUPSEfficiency.setText("<...>");

			GridData constraintFFigureUPSEfficiency = new GridData();
			constraintFFigureUPSEfficiency.verticalAlignment = GridData.CENTER;
			constraintFFigureUPSEfficiency.horizontalAlignment = GridData.CENTER;
			constraintFFigureUPSEfficiency.horizontalIndent = 0;
			constraintFFigureUPSEfficiency.horizontalSpan = 1;
			constraintFFigureUPSEfficiency.verticalSpan = 1;
			constraintFFigureUPSEfficiency.grabExcessHorizontalSpace = true;
			constraintFFigureUPSEfficiency.grabExcessVerticalSpace = false;
			this.add(fFigureUPSEfficiency, constraintFFigureUPSEfficiency);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureUPSNameFigure() {
			return fFigureUPSNameFigure;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureUPSOut_Watt() {
			return fFigureUPSOut_Watt;
		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigureUPSEfficiency() {
			return fFigureUPSEfficiency;
		}

	}

	/**
	 * @generated
	 */
	static final Color THIS_FORE = new Color(null, 0, 0, 0);

}
