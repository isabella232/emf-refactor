package PAM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyElementRequest;

import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class NetworkObjectLinkItemSemanticEditPolicy extends
		PAMBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public NetworkObjectLinkItemSemanticEditPolicy() {
		super(PAMElementTypes.NetworkObjectLink_4002);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyElementCommand(DestroyElementRequest req) {
		return getGEFWrapper(new DestroyElementCommand(req));
	}

}
