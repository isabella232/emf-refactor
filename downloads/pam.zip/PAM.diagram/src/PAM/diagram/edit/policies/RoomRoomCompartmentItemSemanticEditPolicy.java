package PAM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

import PAM.diagram.edit.commands.ClientNode2CreateCommand;
import PAM.diagram.edit.commands.Cooling2CreateCommand;
import PAM.diagram.edit.commands.NetworkNode2CreateCommand;
import PAM.diagram.edit.commands.Room2CreateCommand;
import PAM.diagram.edit.commands.ServerNode2CreateCommand;
import PAM.diagram.edit.commands.UninterruptiblePowerSupply2CreateCommand;
import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class RoomRoomCompartmentItemSemanticEditPolicy extends
		PAMBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public RoomRoomCompartmentItemSemanticEditPolicy() {
		super(PAMElementTypes.Room_2010);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (PAMElementTypes.ClientNode_3007 == req.getElementType()) {
			return getGEFWrapper(new ClientNode2CreateCommand(req));
		}
		if (PAMElementTypes.ServerNode_3008 == req.getElementType()) {
			return getGEFWrapper(new ServerNode2CreateCommand(req));
		}
		if (PAMElementTypes.NetworkNode_3009 == req.getElementType()) {
			return getGEFWrapper(new NetworkNode2CreateCommand(req));
		}
		if (PAMElementTypes.Cooling_3010 == req.getElementType()) {
			return getGEFWrapper(new Cooling2CreateCommand(req));
		}
		if (PAMElementTypes.UninterruptiblePowerSupply_3011 == req
				.getElementType()) {
			return getGEFWrapper(new UninterruptiblePowerSupply2CreateCommand(
					req));
		}
		if (PAMElementTypes.Room_3012 == req.getElementType()) {
			return getGEFWrapper(new Room2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
