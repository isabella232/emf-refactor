package PAM.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;

import PAM.ClientNode;
import PAM.Cooling;
import PAM.NetworkNode;
import PAM.NetworkObjectLink;
import PAM.Nodes;
import PAM.PAMPackage;
import PAM.Room;
import PAM.ServerNode;
import PAM.UninterruptiblePowerSupply;
import PAM.diagram.edit.parts.ClientNode2EditPart;
import PAM.diagram.edit.parts.ClientNodeEditPart;
import PAM.diagram.edit.parts.Cooling2EditPart;
import PAM.diagram.edit.parts.CoolingEditPart;
import PAM.diagram.edit.parts.NetworkNode2EditPart;
import PAM.diagram.edit.parts.NetworkNodeEditPart;
import PAM.diagram.edit.parts.NetworkObjectLinkEditPart;
import PAM.diagram.edit.parts.Room2EditPart;
import PAM.diagram.edit.parts.Room3EditPart;
import PAM.diagram.edit.parts.RoomEditPart;
import PAM.diagram.edit.parts.RoomRoomCompartment2EditPart;
import PAM.diagram.edit.parts.RoomRoomCompartmentEditPart;
import PAM.diagram.edit.parts.ServerNode2EditPart;
import PAM.diagram.edit.parts.ServerNodeEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupply2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEditPart;
import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class PAMDiagramUpdater {

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMNodeDescriptor]*/getSemanticChildren(
			View view) {
		switch (PAMVisualIDRegistry.getVisualID(view)) {
		case RoomEditPart.VISUAL_ID:
			return getRoom_1000SemanticChildren(view);
		case RoomRoomCompartmentEditPart.VISUAL_ID:
			return getRoomRoomCompartment_7003SemanticChildren(view);
		case RoomRoomCompartment2EditPart.VISUAL_ID:
			return getRoomRoomCompartment_7004SemanticChildren(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMNodeDescriptor]*/getRoom_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Room modelElement = (Room) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/();
		for (Iterator/*[?]*/it = modelElement.getContains().iterator(); it
				.hasNext();) {
			Nodes childElement = (Nodes) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == NetworkNodeEditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ServerNodeEditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ClientNodeEditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getSubrooms().iterator(); it
				.hasNext();) {
			Room childElement = (Room) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Room2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getIncludes().iterator(); it
				.hasNext();) {
			Cooling childElement = (Cooling) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == CoolingEditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getApplies().iterator(); it
				.hasNext();) {
			UninterruptiblePowerSupply childElement = (UninterruptiblePowerSupply) it
					.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == UninterruptiblePowerSupplyEditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMNodeDescriptor]*/getRoomRoomCompartment_7003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Room modelElement = (Room) containerView.getElement();
		LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/();
		for (Iterator/*[?]*/it = modelElement.getContains().iterator(); it
				.hasNext();) {
			Nodes childElement = (Nodes) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == ClientNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ServerNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == NetworkNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getIncludes().iterator(); it
				.hasNext();) {
			Cooling childElement = (Cooling) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Cooling2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getApplies().iterator(); it
				.hasNext();) {
			UninterruptiblePowerSupply childElement = (UninterruptiblePowerSupply) it
					.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == UninterruptiblePowerSupply2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getSubrooms().iterator(); it
				.hasNext();) {
			Room childElement = (Room) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Room3EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMNodeDescriptor]*/getRoomRoomCompartment_7004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.EMPTY_LIST;
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.EMPTY_LIST;
		}
		Room modelElement = (Room) containerView.getElement();
		LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMNodeDescriptor]*/();
		for (Iterator/*[?]*/it = modelElement.getContains().iterator(); it
				.hasNext();) {
			Nodes childElement = (Nodes) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == ClientNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ServerNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == NetworkNode2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getIncludes().iterator(); it
				.hasNext();) {
			Cooling childElement = (Cooling) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Cooling2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getApplies().iterator(); it
				.hasNext();) {
			UninterruptiblePowerSupply childElement = (UninterruptiblePowerSupply) it
					.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == UninterruptiblePowerSupply2EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator/*[?]*/it = modelElement.getSubrooms().iterator(); it
				.hasNext();) {
			Room childElement = (Room) it.next();
			int visualID = PAMVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Room3EditPart.VISUAL_ID) {
				result.add(new PAMNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getContainedLinks(
			View view) {
		switch (PAMVisualIDRegistry.getVisualID(view)) {
		case RoomEditPart.VISUAL_ID:
			return getRoom_1000ContainedLinks(view);
		case NetworkNodeEditPart.VISUAL_ID:
			return getNetworkNode_2007ContainedLinks(view);
		case ServerNodeEditPart.VISUAL_ID:
			return getServerNode_2008ContainedLinks(view);
		case ClientNodeEditPart.VISUAL_ID:
			return getClientNode_2009ContainedLinks(view);
		case Room2EditPart.VISUAL_ID:
			return getRoom_2010ContainedLinks(view);
		case CoolingEditPart.VISUAL_ID:
			return getCooling_2011ContainedLinks(view);
		case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_2012ContainedLinks(view);
		case ClientNode2EditPart.VISUAL_ID:
			return getClientNode_3007ContainedLinks(view);
		case ServerNode2EditPart.VISUAL_ID:
			return getServerNode_3008ContainedLinks(view);
		case NetworkNode2EditPart.VISUAL_ID:
			return getNetworkNode_3009ContainedLinks(view);
		case Cooling2EditPart.VISUAL_ID:
			return getCooling_3010ContainedLinks(view);
		case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_3011ContainedLinks(view);
		case Room3EditPart.VISUAL_ID:
			return getRoom_3012ContainedLinks(view);
		case NetworkObjectLinkEditPart.VISUAL_ID:
			return getNetworkObjectLink_4002ContainedLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getIncomingLinks(
			View view) {
		switch (PAMVisualIDRegistry.getVisualID(view)) {
		case NetworkNodeEditPart.VISUAL_ID:
			return getNetworkNode_2007IncomingLinks(view);
		case ServerNodeEditPart.VISUAL_ID:
			return getServerNode_2008IncomingLinks(view);
		case ClientNodeEditPart.VISUAL_ID:
			return getClientNode_2009IncomingLinks(view);
		case Room2EditPart.VISUAL_ID:
			return getRoom_2010IncomingLinks(view);
		case CoolingEditPart.VISUAL_ID:
			return getCooling_2011IncomingLinks(view);
		case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_2012IncomingLinks(view);
		case ClientNode2EditPart.VISUAL_ID:
			return getClientNode_3007IncomingLinks(view);
		case ServerNode2EditPart.VISUAL_ID:
			return getServerNode_3008IncomingLinks(view);
		case NetworkNode2EditPart.VISUAL_ID:
			return getNetworkNode_3009IncomingLinks(view);
		case Cooling2EditPart.VISUAL_ID:
			return getCooling_3010IncomingLinks(view);
		case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_3011IncomingLinks(view);
		case Room3EditPart.VISUAL_ID:
			return getRoom_3012IncomingLinks(view);
		case NetworkObjectLinkEditPart.VISUAL_ID:
			return getNetworkObjectLink_4002IncomingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getOutgoingLinks(
			View view) {
		switch (PAMVisualIDRegistry.getVisualID(view)) {
		case NetworkNodeEditPart.VISUAL_ID:
			return getNetworkNode_2007OutgoingLinks(view);
		case ServerNodeEditPart.VISUAL_ID:
			return getServerNode_2008OutgoingLinks(view);
		case ClientNodeEditPart.VISUAL_ID:
			return getClientNode_2009OutgoingLinks(view);
		case Room2EditPart.VISUAL_ID:
			return getRoom_2010OutgoingLinks(view);
		case CoolingEditPart.VISUAL_ID:
			return getCooling_2011OutgoingLinks(view);
		case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_2012OutgoingLinks(view);
		case ClientNode2EditPart.VISUAL_ID:
			return getClientNode_3007OutgoingLinks(view);
		case ServerNode2EditPart.VISUAL_ID:
			return getServerNode_3008OutgoingLinks(view);
		case NetworkNode2EditPart.VISUAL_ID:
			return getNetworkNode_3009OutgoingLinks(view);
		case Cooling2EditPart.VISUAL_ID:
			return getCooling_3010OutgoingLinks(view);
		case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupply_3011OutgoingLinks(view);
		case Room3EditPart.VISUAL_ID:
			return getRoom_3012OutgoingLinks(view);
		case NetworkObjectLinkEditPart.VISUAL_ID:
			return getNetworkObjectLink_4002OutgoingLinks(view);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_1000ContainedLinks(
			View view) {
		Room modelElement = (Room) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getContainedTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_2007ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_2008ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_2009ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_2010ContainedLinks(
			View view) {
		Room modelElement = (Room) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getContainedTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_2011ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_2012ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_3007ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_3008ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_3009ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_3010ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_3011ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_3012ContainedLinks(
			View view) {
		Room modelElement = (Room) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getContainedTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkObjectLink_4002ContainedLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_2007IncomingLinks(
			View view) {
		NetworkNode modelElement = (NetworkNode) view.getElement();
		Map/*[org.eclipse.emf.ecore.EObject, java.util.Collection<org.eclipse.emf.ecore.EStructuralFeature.Setting>]*/crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getIncomingTypeModelFacetLinks_NetworkObjectLink_4002(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_2008IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_2009IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_2010IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_2011IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_2012IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_3007IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_3008IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_3009IncomingLinks(
			View view) {
		NetworkNode modelElement = (NetworkNode) view.getElement();
		Map/*[org.eclipse.emf.ecore.EObject, java.util.Collection<org.eclipse.emf.ecore.EStructuralFeature.Setting>]*/crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getIncomingTypeModelFacetLinks_NetworkObjectLink_4002(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_3010IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_3011IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_3012IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkObjectLink_4002IncomingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_2007OutgoingLinks(
			View view) {
		NetworkNode modelElement = (NetworkNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_2008OutgoingLinks(
			View view) {
		ServerNode modelElement = (ServerNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_2009OutgoingLinks(
			View view) {
		ClientNode modelElement = (ClientNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_2010OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_2011OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_2012OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getClientNode_3007OutgoingLinks(
			View view) {
		ClientNode modelElement = (ClientNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getServerNode_3008OutgoingLinks(
			View view) {
		ServerNode modelElement = (ServerNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkNode_3009OutgoingLinks(
			View view) {
		NetworkNode modelElement = (NetworkNode) view.getElement();
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getCooling_3010OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getUninterruptiblePowerSupply_3011OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getRoom_3012OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public static List/*[PAM.diagram.part.PAMLinkDescriptor]*/getNetworkObjectLink_4002OutgoingLinks(
			View view) {
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	private static Collection/*[PAM.diagram.part.PAMLinkDescriptor]*/getContainedTypeModelFacetLinks_NetworkObjectLink_4002(
			Room container) {
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		for (Iterator/*[?]*/links = container.getLinks().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof NetworkObjectLink) {
				continue;
			}
			NetworkObjectLink link = (NetworkObjectLink) linkObject;
			if (NetworkObjectLinkEditPart.VISUAL_ID != PAMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			NetworkNode dst = link.getConnect1();
			Nodes src = link.getConnect0();
			result.add(new PAMLinkDescriptor(src, dst, link,
					PAMElementTypes.NetworkObjectLink_4002,
					NetworkObjectLinkEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection/*[PAM.diagram.part.PAMLinkDescriptor]*/getIncomingTypeModelFacetLinks_NetworkObjectLink_4002(
			NetworkNode target,
			Map/*[org.eclipse.emf.ecore.EObject, java.util.Collection<org.eclipse.emf.ecore.EStructuralFeature.Setting>]*/crossReferences) {
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		Collection/*[org.eclipse.emf.ecore.EStructuralFeature.Setting]*/settings = (Collection) crossReferences
				.get(target);
		for (Iterator/*[org.eclipse.emf.ecore.EStructuralFeature.Setting]*/it = settings
				.iterator(); it.hasNext();) {
			EStructuralFeature.Setting setting = (EStructuralFeature.Setting) it
					.next();
			if (setting.getEStructuralFeature() != PAMPackage.eINSTANCE
					.getNetworkObjectLink_Connect1()
					|| false == setting.getEObject() instanceof NetworkObjectLink) {
				continue;
			}
			NetworkObjectLink link = (NetworkObjectLink) setting.getEObject();
			if (NetworkObjectLinkEditPart.VISUAL_ID != PAMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			Nodes src = link.getConnect0();
			result.add(new PAMLinkDescriptor(src, target, link,
					PAMElementTypes.NetworkObjectLink_4002,
					NetworkObjectLinkEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection/*[PAM.diagram.part.PAMLinkDescriptor]*/getOutgoingTypeModelFacetLinks_NetworkObjectLink_4002(
			Nodes source) {
		Room container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Room) {
				container = (Room) element;
			}
		}
		if (container == null) {
			return Collections.EMPTY_LIST;
		}
		LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/result = new LinkedList/*[PAM.diagram.part.PAMLinkDescriptor]*/();
		for (Iterator/*[?]*/links = container.getLinks().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof NetworkObjectLink) {
				continue;
			}
			NetworkObjectLink link = (NetworkObjectLink) linkObject;
			if (NetworkObjectLinkEditPart.VISUAL_ID != PAMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			NetworkNode dst = link.getConnect1();
			Nodes src = link.getConnect0();
			if (src != source) {
				continue;
			}
			result.add(new PAMLinkDescriptor(src, dst, link,
					PAMElementTypes.NetworkObjectLink_4002,
					NetworkObjectLinkEditPart.VISUAL_ID));
		}
		return result;
	}

}
