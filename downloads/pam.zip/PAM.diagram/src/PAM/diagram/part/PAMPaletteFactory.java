package PAM.diagram.part;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;

import PAM.diagram.providers.PAMElementTypes;

/**
 * @generated
 */
public class PAMPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createNodes1Group());
		paletteRoot.add(createLinks2Group());
	}

	/**
	 * Creates "Nodes" palette tool group
	 * @generated
	 */
	private PaletteContainer createNodes1Group() {
		PaletteGroup paletteContainer = new PaletteGroup(
				Messages.Nodes1Group_title);
		paletteContainer.setId("createNodes1Group"); //$NON-NLS-1$
		paletteContainer.setDescription(Messages.Nodes1Group_desc);
		paletteContainer.add(createCreatenetworknode1CreationTool());
		paletteContainer.add(createCreateservernode2CreationTool());
		paletteContainer.add(createCreateclientnode3CreationTool());
		paletteContainer
				.add(createCreateUPSUninterruptiblePowerSupply4CreationTool());
		paletteContainer.add(createCreatecooling5CreationTool());
		paletteContainer.add(createCreatearoom6CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Links" palette tool group
	 * @generated
	 */
	private PaletteContainer createLinks2Group() {
		PaletteGroup paletteContainer = new PaletteGroup(
				Messages.Links2Group_title);
		paletteContainer.setId("createLinks2Group"); //$NON-NLS-1$
		paletteContainer.setDescription(Messages.Links2Group_desc);
		paletteContainer.add(createCreatelink1CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreatenetworknode1CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.NetworkNode_2007);
		types.add(PAMElementTypes.NetworkNode_3009);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Createnetworknode1CreationTool_title,
				Messages.Createnetworknode1CreationTool_desc, types);
		entry.setId("createCreatenetworknode1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.NetworkNode_2007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateservernode2CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.ServerNode_2008);
		types.add(PAMElementTypes.ServerNode_3008);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Createservernode2CreationTool_title,
				Messages.Createservernode2CreationTool_desc, types);
		entry.setId("createCreateservernode2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.ServerNode_2008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateclientnode3CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.ClientNode_2009);
		types.add(PAMElementTypes.ClientNode_3007);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Createclientnode3CreationTool_title,
				Messages.Createclientnode3CreationTool_desc, types);
		entry.setId("createCreateclientnode3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.ClientNode_2009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreateUPSUninterruptiblePowerSupply4CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.UninterruptiblePowerSupply_3011);
		types.add(PAMElementTypes.UninterruptiblePowerSupply_2012);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.CreateUPSUninterruptiblePowerSupply4CreationTool_title,
				Messages.CreateUPSUninterruptiblePowerSupply4CreationTool_desc,
				types);
		entry.setId("createCreateUPSUninterruptiblePowerSupply4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.UninterruptiblePowerSupply_3011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreatecooling5CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.Cooling_3010);
		types.add(PAMElementTypes.Cooling_2011);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Createcooling5CreationTool_title,
				Messages.Createcooling5CreationTool_desc, types);
		entry.setId("createCreatecooling5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.Cooling_3010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreatearoom6CreationTool() {
		ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/types = new ArrayList/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/(
				2);
		types.add(PAMElementTypes.Room_2010);
		types.add(PAMElementTypes.Room_3012);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Createaroom6CreationTool_title,
				Messages.Createaroom6CreationTool_desc, types);
		entry.setId("createCreatearoom6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.Room_2010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCreatelink1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Createlink1CreationTool_title,
				Messages.Createlink1CreationTool_desc,
				Collections
						.singletonList(PAMElementTypes.NetworkObjectLink_4002));
		entry.setId("createCreatelink1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(PAMElementTypes
				.getImageDescriptor(PAMElementTypes.NetworkObjectLink_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(
				String title,
				String description,
				List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(
				String title,
				String description,
				List/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
