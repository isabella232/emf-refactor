package PAM.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;

import PAM.PAMPackage;
import PAM.Room;
import PAM.diagram.edit.parts.ClientNode2EditPart;
import PAM.diagram.edit.parts.ClientNodeEditPart;
import PAM.diagram.edit.parts.ClientNodeMFLOPs2EditPart;
import PAM.diagram.edit.parts.ClientNodeMFLOPsEditPart;
import PAM.diagram.edit.parts.ClientNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.ClientNodeMax_WattEditPart;
import PAM.diagram.edit.parts.ClientNodeName2EditPart;
import PAM.diagram.edit.parts.ClientNodeNameEditPart;
import PAM.diagram.edit.parts.Cooling2EditPart;
import PAM.diagram.edit.parts.CoolingCooling_Capacity2EditPart;
import PAM.diagram.edit.parts.CoolingCooling_CapacityEditPart;
import PAM.diagram.edit.parts.CoolingEditPart;
import PAM.diagram.edit.parts.CoolingMax_Watt2EditPart;
import PAM.diagram.edit.parts.CoolingMax_WattEditPart;
import PAM.diagram.edit.parts.CoolingName2EditPart;
import PAM.diagram.edit.parts.CoolingNameEditPart;
import PAM.diagram.edit.parts.NetworkNode2EditPart;
import PAM.diagram.edit.parts.NetworkNodeEditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_Throughput2EditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_ThroughputEditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_WattEditPart;
import PAM.diagram.edit.parts.NetworkNodeName2EditPart;
import PAM.diagram.edit.parts.NetworkNodeNameEditPart;
import PAM.diagram.edit.parts.NetworkObjectLinkEditPart;
import PAM.diagram.edit.parts.Room2EditPart;
import PAM.diagram.edit.parts.Room3EditPart;
import PAM.diagram.edit.parts.RoomEditPart;
import PAM.diagram.edit.parts.RoomName2EditPart;
import PAM.diagram.edit.parts.RoomNameEditPart;
import PAM.diagram.edit.parts.RoomRoomCompartment2EditPart;
import PAM.diagram.edit.parts.RoomRoomCompartmentEditPart;
import PAM.diagram.edit.parts.ServerNode2EditPart;
import PAM.diagram.edit.parts.ServerNodeAct_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeAct_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeEditPart;
import PAM.diagram.edit.parts.ServerNodeIdle_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeIdle_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeMFLOPs2EditPart;
import PAM.diagram.edit.parts.ServerNodeMFLOPsEditPart;
import PAM.diagram.edit.parts.ServerNodeMax_Capacity2EditPart;
import PAM.diagram.edit.parts.ServerNodeMax_CapacityEditPart;
import PAM.diagram.edit.parts.ServerNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeMax_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeName2EditPart;
import PAM.diagram.edit.parts.ServerNodeNameEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupply2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEfficiency2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEfficiencyEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyName2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyNameEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyOut_Watt2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyOut_WattEditPart;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class PAMVisualIDRegistry {

	/**
	 * @generated
	 */
	private static final String DEBUG_KEY = "PAM.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (RoomEditPart.MODEL_ID.equals(view.getType())) {
				return RoomEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return PAM.diagram.part.PAMVisualIDRegistry.getVisualID(view.getType());
	}

	/**
	 * @generated
	 */
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	 * @generated
	 */
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(
					Platform.getDebugOption(DEBUG_KEY))) {
				PAMDiagramEditorPlugin.getInstance().logError(
						"Unable to parse view type as a visualID number: "
								+ type);
			}
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	 * @generated
	 */
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (PAMPackage.eINSTANCE.getRoom()
				.isSuperTypeOf(domainElement.eClass())
				&& isDiagram((Room) domainElement)) {
			return RoomEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = PAM.diagram.part.PAMVisualIDRegistry
				.getModelID(containerView);
		if (!RoomEditPart.MODEL_ID.equals(containerModelID)) {
			return -1;
		}
		int containerVisualID;
		if (RoomEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = PAM.diagram.part.PAMVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = RoomEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case RoomEditPart.VISUAL_ID:
			if (PAMPackage.eINSTANCE.getNetworkNode().isSuperTypeOf(
					domainElement.eClass())) {
				return NetworkNodeEditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getServerNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ServerNodeEditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getClientNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ClientNodeEditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getRoom().isSuperTypeOf(
					domainElement.eClass())) {
				return Room2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getCooling().isSuperTypeOf(
					domainElement.eClass())) {
				return CoolingEditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getUninterruptiblePowerSupply()
					.isSuperTypeOf(domainElement.eClass())) {
				return UninterruptiblePowerSupplyEditPart.VISUAL_ID;
			}
			break;
		case RoomRoomCompartmentEditPart.VISUAL_ID:
			if (PAMPackage.eINSTANCE.getClientNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ClientNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getServerNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ServerNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getNetworkNode().isSuperTypeOf(
					domainElement.eClass())) {
				return NetworkNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getCooling().isSuperTypeOf(
					domainElement.eClass())) {
				return Cooling2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getUninterruptiblePowerSupply()
					.isSuperTypeOf(domainElement.eClass())) {
				return UninterruptiblePowerSupply2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getRoom().isSuperTypeOf(
					domainElement.eClass())) {
				return Room3EditPart.VISUAL_ID;
			}
			break;
		case RoomRoomCompartment2EditPart.VISUAL_ID:
			if (PAMPackage.eINSTANCE.getClientNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ClientNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getServerNode().isSuperTypeOf(
					domainElement.eClass())) {
				return ServerNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getNetworkNode().isSuperTypeOf(
					domainElement.eClass())) {
				return NetworkNode2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getCooling().isSuperTypeOf(
					domainElement.eClass())) {
				return Cooling2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getUninterruptiblePowerSupply()
					.isSuperTypeOf(domainElement.eClass())) {
				return UninterruptiblePowerSupply2EditPart.VISUAL_ID;
			}
			if (PAMPackage.eINSTANCE.getRoom().isSuperTypeOf(
					domainElement.eClass())) {
				return Room3EditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = PAM.diagram.part.PAMVisualIDRegistry
				.getModelID(containerView);
		if (!RoomEditPart.MODEL_ID.equals(containerModelID)) {
			return false;
		}
		int containerVisualID;
		if (RoomEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = PAM.diagram.part.PAMVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = RoomEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case RoomEditPart.VISUAL_ID:
			if (NetworkNodeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ClientNodeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Room2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CoolingEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupplyEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NetworkNodeEditPart.VISUAL_ID:
			if (NetworkNodeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNodeMax_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNodeMax_ThroughputEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ServerNodeEditPart.VISUAL_ID:
			if (ServerNodeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMax_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeIdle_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeAct_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMax_CapacityEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMFLOPsEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ClientNodeEditPart.VISUAL_ID:
			if (ClientNodeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ClientNodeMax_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ClientNodeMFLOPsEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Room2EditPart.VISUAL_ID:
			if (RoomNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (RoomRoomCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case CoolingEditPart.VISUAL_ID:
			if (CoolingNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CoolingMax_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CoolingCooling_CapacityEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
			if (UninterruptiblePowerSupplyNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupplyOut_WattEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupplyEfficiencyEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ClientNode2EditPart.VISUAL_ID:
			if (ClientNodeName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ClientNodeMax_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ClientNodeMFLOPs2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ServerNode2EditPart.VISUAL_ID:
			if (ServerNodeName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMax_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeIdle_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeAct_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMax_Capacity2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNodeMFLOPs2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NetworkNode2EditPart.VISUAL_ID:
			if (NetworkNodeName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNodeMax_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNodeMax_Throughput2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Cooling2EditPart.VISUAL_ID:
			if (CoolingName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CoolingMax_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (CoolingCooling_Capacity2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
			if (UninterruptiblePowerSupplyName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupplyOut_Watt2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupplyEfficiency2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Room3EditPart.VISUAL_ID:
			if (RoomName2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (RoomRoomCompartment2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case RoomRoomCompartmentEditPart.VISUAL_ID:
			if (ClientNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Cooling2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupply2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Room3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case RoomRoomCompartment2EditPart.VISUAL_ID:
			if (ClientNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ServerNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkNode2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Cooling2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UninterruptiblePowerSupply2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (Room3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (PAMPackage.eINSTANCE.getNetworkObjectLink().isSuperTypeOf(
				domainElement.eClass())) {
			return NetworkObjectLinkEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * User can change implementation of this method to handle some specific
	 * situations not covered by default logic.
	 * 
	 * @generated
	 */
	private static boolean isDiagram(Room element) {
		return true;
	}

}
