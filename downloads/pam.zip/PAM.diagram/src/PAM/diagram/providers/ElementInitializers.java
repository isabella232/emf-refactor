package PAM.diagram.providers;

import PAM.diagram.part.PAMDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = PAMDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			PAMDiagramEditorPlugin.getInstance().setElementInitializers(
					cached = new ElementInitializers());
		}
		return cached;
	}
}
