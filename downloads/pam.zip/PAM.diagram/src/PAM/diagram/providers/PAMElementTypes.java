package PAM.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

import PAM.PAMPackage;
import PAM.diagram.edit.parts.ClientNode2EditPart;
import PAM.diagram.edit.parts.ClientNodeEditPart;
import PAM.diagram.edit.parts.Cooling2EditPart;
import PAM.diagram.edit.parts.CoolingEditPart;
import PAM.diagram.edit.parts.NetworkNode2EditPart;
import PAM.diagram.edit.parts.NetworkNodeEditPart;
import PAM.diagram.edit.parts.NetworkObjectLinkEditPart;
import PAM.diagram.edit.parts.Room2EditPart;
import PAM.diagram.edit.parts.Room3EditPart;
import PAM.diagram.edit.parts.RoomEditPart;
import PAM.diagram.edit.parts.ServerNode2EditPart;
import PAM.diagram.edit.parts.ServerNodeEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupply2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEditPart;
import PAM.diagram.part.PAMDiagramEditorPlugin;

/**
 * @generated
 */
public class PAMElementTypes {

	/**
	 * @generated
	 */
	private PAMElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map/*[org.eclipse.gmf.runtime.emf.type.core.IElementType, org.eclipse.emf.ecore.ENamedElement]*/elements;

	/**
	 * @generated
	 */
	private static ImageRegistry imageRegistry;

	/**
	 * @generated
	 */
	private static Set/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType Room_1000 = getElementType("PAM.diagram.Room_1000"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType NetworkNode_2007 = getElementType("PAM.diagram.NetworkNode_2007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ServerNode_2008 = getElementType("PAM.diagram.ServerNode_2008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ClientNode_2009 = getElementType("PAM.diagram.ClientNode_2009"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Room_2010 = getElementType("PAM.diagram.Room_2010"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Cooling_2011 = getElementType("PAM.diagram.Cooling_2011"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType UninterruptiblePowerSupply_2012 = getElementType("PAM.diagram.UninterruptiblePowerSupply_2012"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ClientNode_3007 = getElementType("PAM.diagram.ClientNode_3007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ServerNode_3008 = getElementType("PAM.diagram.ServerNode_3008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType NetworkNode_3009 = getElementType("PAM.diagram.NetworkNode_3009"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Cooling_3010 = getElementType("PAM.diagram.Cooling_3010"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType UninterruptiblePowerSupply_3011 = getElementType("PAM.diagram.UninterruptiblePowerSupply_3011"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Room_3012 = getElementType("PAM.diagram.Room_3012"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType NetworkObjectLink_4002 = getElementType("PAM.diagram.NetworkObjectLink_4002"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	private static ImageRegistry getImageRegistry() {
		if (imageRegistry == null) {
			imageRegistry = new ImageRegistry();
		}
		return imageRegistry;
	}

	/**
	 * @generated
	 */
	private static String getImageRegistryKey(ENamedElement element) {
		return element.getName();
	}

	/**
	 * @generated
	 */
	private static ImageDescriptor getProvidedImageDescriptor(
			ENamedElement element) {
		if (element instanceof EStructuralFeature) {
			EStructuralFeature feature = ((EStructuralFeature) element);
			EClass eContainingClass = feature.getEContainingClass();
			EClassifier eType = feature.getEType();
			if (eContainingClass != null && !eContainingClass.isAbstract()) {
				element = eContainingClass;
			} else if (eType instanceof EClass
					&& !((EClass) eType).isAbstract()) {
				element = eType;
			}
		}
		if (element instanceof EClass) {
			EClass eClass = (EClass) element;
			if (!eClass.isAbstract()) {
				return PAMDiagramEditorPlugin.getInstance()
						.getItemImageDescriptor(
								eClass.getEPackage().getEFactoryInstance()
										.create(eClass));
			}
		}
		// TODO : support structural features
		return null;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		String key = getImageRegistryKey(element);
		ImageDescriptor imageDescriptor = getImageRegistry().getDescriptor(key);
		if (imageDescriptor == null) {
			imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
		}
		return imageDescriptor;
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		String key = getImageRegistryKey(element);
		Image image = getImageRegistry().get(key);
		if (image == null) {
			ImageDescriptor imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
			image = getImageRegistry().get(key);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImage(element);
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap/*[org.eclipse.gmf.runtime.emf.type.core.IElementType, org.eclipse.emf.ecore.ENamedElement]*/();

			elements.put(Room_1000, PAMPackage.eINSTANCE.getRoom());

			elements.put(NetworkNode_2007,
					PAMPackage.eINSTANCE.getNetworkNode());

			elements.put(ServerNode_2008, PAMPackage.eINSTANCE.getServerNode());

			elements.put(ClientNode_2009, PAMPackage.eINSTANCE.getClientNode());

			elements.put(Room_2010, PAMPackage.eINSTANCE.getRoom());

			elements.put(Cooling_2011, PAMPackage.eINSTANCE.getCooling());

			elements.put(UninterruptiblePowerSupply_2012,
					PAMPackage.eINSTANCE.getUninterruptiblePowerSupply());

			elements.put(ClientNode_3007, PAMPackage.eINSTANCE.getClientNode());

			elements.put(ServerNode_3008, PAMPackage.eINSTANCE.getServerNode());

			elements.put(NetworkNode_3009,
					PAMPackage.eINSTANCE.getNetworkNode());

			elements.put(Cooling_3010, PAMPackage.eINSTANCE.getCooling());

			elements.put(UninterruptiblePowerSupply_3011,
					PAMPackage.eINSTANCE.getUninterruptiblePowerSupply());

			elements.put(Room_3012, PAMPackage.eINSTANCE.getRoom());

			elements.put(NetworkObjectLink_4002,
					PAMPackage.eINSTANCE.getNetworkObjectLink());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet/*[org.eclipse.gmf.runtime.emf.type.core.IElementType]*/();
			KNOWN_ELEMENT_TYPES.add(Room_1000);
			KNOWN_ELEMENT_TYPES.add(NetworkNode_2007);
			KNOWN_ELEMENT_TYPES.add(ServerNode_2008);
			KNOWN_ELEMENT_TYPES.add(ClientNode_2009);
			KNOWN_ELEMENT_TYPES.add(Room_2010);
			KNOWN_ELEMENT_TYPES.add(Cooling_2011);
			KNOWN_ELEMENT_TYPES.add(UninterruptiblePowerSupply_2012);
			KNOWN_ELEMENT_TYPES.add(ClientNode_3007);
			KNOWN_ELEMENT_TYPES.add(ServerNode_3008);
			KNOWN_ELEMENT_TYPES.add(NetworkNode_3009);
			KNOWN_ELEMENT_TYPES.add(Cooling_3010);
			KNOWN_ELEMENT_TYPES.add(UninterruptiblePowerSupply_3011);
			KNOWN_ELEMENT_TYPES.add(Room_3012);
			KNOWN_ELEMENT_TYPES.add(NetworkObjectLink_4002);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case RoomEditPart.VISUAL_ID:
			return Room_1000;
		case NetworkNodeEditPart.VISUAL_ID:
			return NetworkNode_2007;
		case ServerNodeEditPart.VISUAL_ID:
			return ServerNode_2008;
		case ClientNodeEditPart.VISUAL_ID:
			return ClientNode_2009;
		case Room2EditPart.VISUAL_ID:
			return Room_2010;
		case CoolingEditPart.VISUAL_ID:
			return Cooling_2011;
		case UninterruptiblePowerSupplyEditPart.VISUAL_ID:
			return UninterruptiblePowerSupply_2012;
		case ClientNode2EditPart.VISUAL_ID:
			return ClientNode_3007;
		case ServerNode2EditPart.VISUAL_ID:
			return ServerNode_3008;
		case NetworkNode2EditPart.VISUAL_ID:
			return NetworkNode_3009;
		case Cooling2EditPart.VISUAL_ID:
			return Cooling_3010;
		case UninterruptiblePowerSupply2EditPart.VISUAL_ID:
			return UninterruptiblePowerSupply_3011;
		case Room3EditPart.VISUAL_ID:
			return Room_3012;
		case NetworkObjectLinkEditPart.VISUAL_ID:
			return NetworkObjectLink_4002;
		}
		return null;
	}

}
