package PAM.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

import PAM.PAMPackage;
import PAM.diagram.edit.parts.ClientNodeMFLOPs2EditPart;
import PAM.diagram.edit.parts.ClientNodeMFLOPsEditPart;
import PAM.diagram.edit.parts.ClientNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.ClientNodeMax_WattEditPart;
import PAM.diagram.edit.parts.ClientNodeName2EditPart;
import PAM.diagram.edit.parts.ClientNodeNameEditPart;
import PAM.diagram.edit.parts.CoolingCooling_Capacity2EditPart;
import PAM.diagram.edit.parts.CoolingCooling_CapacityEditPart;
import PAM.diagram.edit.parts.CoolingMax_Watt2EditPart;
import PAM.diagram.edit.parts.CoolingMax_WattEditPart;
import PAM.diagram.edit.parts.CoolingName2EditPart;
import PAM.diagram.edit.parts.CoolingNameEditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_Throughput2EditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_ThroughputEditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.NetworkNodeMax_WattEditPart;
import PAM.diagram.edit.parts.NetworkNodeName2EditPart;
import PAM.diagram.edit.parts.NetworkNodeNameEditPart;
import PAM.diagram.edit.parts.RoomName2EditPart;
import PAM.diagram.edit.parts.RoomNameEditPart;
import PAM.diagram.edit.parts.ServerNodeAct_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeAct_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeIdle_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeIdle_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeMFLOPs2EditPart;
import PAM.diagram.edit.parts.ServerNodeMFLOPsEditPart;
import PAM.diagram.edit.parts.ServerNodeMax_Capacity2EditPart;
import PAM.diagram.edit.parts.ServerNodeMax_CapacityEditPart;
import PAM.diagram.edit.parts.ServerNodeMax_Watt2EditPart;
import PAM.diagram.edit.parts.ServerNodeMax_WattEditPart;
import PAM.diagram.edit.parts.ServerNodeName2EditPart;
import PAM.diagram.edit.parts.ServerNodeNameEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEfficiency2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyEfficiencyEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyName2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyNameEditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyOut_Watt2EditPart;
import PAM.diagram.edit.parts.UninterruptiblePowerSupplyOut_WattEditPart;
import PAM.diagram.parsers.MessageFormatParser;
import PAM.diagram.part.PAMVisualIDRegistry;

/**
 * @generated
 */
public class PAMParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser networkNodeName_5039Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeName_5039Parser() {
		if (networkNodeName_5039Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			networkNodeName_5039Parser = parser;
		}
		return networkNodeName_5039Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkNodeMax_Watt_5040Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeMax_Watt_5040Parser() {
		if (networkNodeMax_Watt_5040Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			networkNodeMax_Watt_5040Parser = parser;
		}
		return networkNodeMax_Watt_5040Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkNodeMax_Throughput_5041Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeMax_Throughput_5041Parser() {
		if (networkNodeMax_Throughput_5041Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNetworkNode_Max_Throughput() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNetworkNode_Max_Throughput() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			parser.setEditPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			networkNodeMax_Throughput_5041Parser = parser;
		}
		return networkNodeMax_Throughput_5041Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeName_5042Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeName_5042Parser() {
		if (serverNodeName_5042Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			serverNodeName_5042Parser = parser;
		}
		return serverNodeName_5042Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMax_Watt_5043Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMax_Watt_5043Parser() {
		if (serverNodeMax_Watt_5043Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeMax_Watt_5043Parser = parser;
		}
		return serverNodeMax_Watt_5043Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeIdle_Watt_5044Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeIdle_Watt_5044Parser() {
		if (serverNodeIdle_Watt_5044Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Idle_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Idle_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeIdle_Watt_5044Parser = parser;
		}
		return serverNodeIdle_Watt_5044Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeAct_Watt_5045Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeAct_Watt_5045Parser() {
		if (serverNodeAct_Watt_5045Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Act_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Act_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeAct_Watt_5045Parser = parser;
		}
		return serverNodeAct_Watt_5045Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMax_Capacity_5046Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMax_Capacity_5046Parser() {
		if (serverNodeMax_Capacity_5046Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Max_Capacity() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Max_Capacity() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			parser.setEditPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			serverNodeMax_Capacity_5046Parser = parser;
		}
		return serverNodeMax_Capacity_5046Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMFLOPs_5047Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMFLOPs_5047Parser() {
		if (serverNodeMFLOPs_5047Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_MFLOPs() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_MFLOPs() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditorPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			serverNodeMFLOPs_5047Parser = parser;
		}
		return serverNodeMFLOPs_5047Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeName_5048Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeName_5048Parser() {
		if (clientNodeName_5048Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			clientNodeName_5048Parser = parser;
		}
		return clientNodeName_5048Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeMax_Watt_5049Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeMax_Watt_5049Parser() {
		if (clientNodeMax_Watt_5049Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			clientNodeMax_Watt_5049Parser = parser;
		}
		return clientNodeMax_Watt_5049Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeMFLOPs_5050Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeMFLOPs_5050Parser() {
		if (clientNodeMFLOPs_5050Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getClientNode_MFLOPs() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getClientNode_MFLOPs() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditorPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			clientNodeMFLOPs_5050Parser = parser;
		}
		return clientNodeMFLOPs_5050Parser;
	}

	/**
	 * @generated
	 */
	private IParser roomName_5070Parser;

	/**
	 * @generated
	 */
	private IParser getRoomName_5070Parser() {
		if (roomName_5070Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getRoom_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getRoom_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			roomName_5070Parser = parser;
		}
		return roomName_5070Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingName_5071Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingName_5071Parser() {
		if (coolingName_5071Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			coolingName_5071Parser = parser;
		}
		return coolingName_5071Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingMax_Watt_5072Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingMax_Watt_5072Parser() {
		if (coolingMax_Watt_5072Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			coolingMax_Watt_5072Parser = parser;
		}
		return coolingMax_Watt_5072Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingCooling_Capacity_5073Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingCooling_Capacity_5073Parser() {
		if (coolingCooling_Capacity_5073Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Cooling_Capacity() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Cooling_Capacity() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			coolingCooling_Capacity_5073Parser = parser;
		}
		return coolingCooling_Capacity_5073Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyName_5074Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyName_5074Parser() {
		if (uninterruptiblePowerSupplyName_5074Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			uninterruptiblePowerSupplyName_5074Parser = parser;
		}
		return uninterruptiblePowerSupplyName_5074Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyOut_Watt_5075Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyOut_Watt_5075Parser() {
		if (uninterruptiblePowerSupplyOut_Watt_5075Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Out_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Out_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			uninterruptiblePowerSupplyOut_Watt_5075Parser = parser;
		}
		return uninterruptiblePowerSupplyOut_Watt_5075Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyEfficiency_5076Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyEfficiency_5076Parser() {
		if (uninterruptiblePowerSupplyEfficiency_5076Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Efficiency() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Efficiency() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Efficiency: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Efficiency: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Efficiency: {0}"); //$NON-NLS-1$
			uninterruptiblePowerSupplyEfficiency_5076Parser = parser;
		}
		return uninterruptiblePowerSupplyEfficiency_5076Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeName_5051Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeName_5051Parser() {
		if (clientNodeName_5051Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			clientNodeName_5051Parser = parser;
		}
		return clientNodeName_5051Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeMax_Watt_5052Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeMax_Watt_5052Parser() {
		if (clientNodeMax_Watt_5052Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			clientNodeMax_Watt_5052Parser = parser;
		}
		return clientNodeMax_Watt_5052Parser;
	}

	/**
	 * @generated
	 */
	private IParser clientNodeMFLOPs_5053Parser;

	/**
	 * @generated
	 */
	private IParser getClientNodeMFLOPs_5053Parser() {
		if (clientNodeMFLOPs_5053Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getClientNode_MFLOPs() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getClientNode_MFLOPs() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditorPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			clientNodeMFLOPs_5053Parser = parser;
		}
		return clientNodeMFLOPs_5053Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeName_5054Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeName_5054Parser() {
		if (serverNodeName_5054Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			serverNodeName_5054Parser = parser;
		}
		return serverNodeName_5054Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMax_Watt_5055Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMax_Watt_5055Parser() {
		if (serverNodeMax_Watt_5055Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeMax_Watt_5055Parser = parser;
		}
		return serverNodeMax_Watt_5055Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeIdle_Watt_5056Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeIdle_Watt_5056Parser() {
		if (serverNodeIdle_Watt_5056Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Idle_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Idle_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Idle_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeIdle_Watt_5056Parser = parser;
		}
		return serverNodeIdle_Watt_5056Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeAct_Watt_5057Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeAct_Watt_5057Parser() {
		if (serverNodeAct_Watt_5057Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Act_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Act_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Act_Watt: {0} Watt"); //$NON-NLS-1$
			serverNodeAct_Watt_5057Parser = parser;
		}
		return serverNodeAct_Watt_5057Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMax_Capacity_5058Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMax_Capacity_5058Parser() {
		if (serverNodeMax_Capacity_5058Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Max_Capacity() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_Max_Capacity() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			parser.setEditPattern("Max_Capacity: {0} GB"); //$NON-NLS-1$
			serverNodeMax_Capacity_5058Parser = parser;
		}
		return serverNodeMax_Capacity_5058Parser;
	}

	/**
	 * @generated
	 */
	private IParser serverNodeMFLOPs_5059Parser;

	/**
	 * @generated
	 */
	private IParser getServerNodeMFLOPs_5059Parser() {
		if (serverNodeMFLOPs_5059Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_MFLOPs() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getServerNode_MFLOPs() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditorPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			parser.setEditPattern("MFLOPs: {0} MFLOP/s"); //$NON-NLS-1$
			serverNodeMFLOPs_5059Parser = parser;
		}
		return serverNodeMFLOPs_5059Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkNodeName_5060Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeName_5060Parser() {
		if (networkNodeName_5060Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			networkNodeName_5060Parser = parser;
		}
		return networkNodeName_5060Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkNodeMax_Watt_5061Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeMax_Watt_5061Parser() {
		if (networkNodeMax_Watt_5061Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNodes_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			networkNodeMax_Watt_5061Parser = parser;
		}
		return networkNodeMax_Watt_5061Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkNodeMax_Throughput_5062Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkNodeMax_Throughput_5062Parser() {
		if (networkNodeMax_Throughput_5062Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getNetworkNode_Max_Throughput() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getNetworkNode_Max_Throughput() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			parser.setEditPattern("Max_Throughput: {0} Gbps"); //$NON-NLS-1$
			networkNodeMax_Throughput_5062Parser = parser;
		}
		return networkNodeMax_Throughput_5062Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingName_5063Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingName_5063Parser() {
		if (coolingName_5063Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			coolingName_5063Parser = parser;
		}
		return coolingName_5063Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingMax_Watt_5064Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingMax_Watt_5064Parser() {
		if (coolingMax_Watt_5064Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Max_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Max_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Max_Watt: {0} Watt"); //$NON-NLS-1$
			coolingMax_Watt_5064Parser = parser;
		}
		return coolingMax_Watt_5064Parser;
	}

	/**
	 * @generated
	 */
	private IParser coolingCooling_Capacity_5065Parser;

	/**
	 * @generated
	 */
	private IParser getCoolingCooling_Capacity_5065Parser() {
		if (coolingCooling_Capacity_5065Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Cooling_Capacity() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getCooling_Cooling_Capacity() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Cooling_Capacity: {0} Watt"); //$NON-NLS-1$
			coolingCooling_Capacity_5065Parser = parser;
		}
		return coolingCooling_Capacity_5065Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyName_5066Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyName_5066Parser() {
		if (uninterruptiblePowerSupplyName_5066Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Name: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Name: {0}"); //$NON-NLS-1$
			uninterruptiblePowerSupplyName_5066Parser = parser;
		}
		return uninterruptiblePowerSupplyName_5066Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyOut_Watt_5067Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyOut_Watt_5067Parser() {
		if (uninterruptiblePowerSupplyOut_Watt_5067Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Out_Watt() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Out_Watt() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditorPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			parser.setEditPattern("Out_Watt: {0} Watt"); //$NON-NLS-1$
			uninterruptiblePowerSupplyOut_Watt_5067Parser = parser;
		}
		return uninterruptiblePowerSupplyOut_Watt_5067Parser;
	}

	/**
	 * @generated
	 */
	private IParser uninterruptiblePowerSupplyEfficiency_5068Parser;

	/**
	 * @generated
	 */
	private IParser getUninterruptiblePowerSupplyEfficiency_5068Parser() {
		if (uninterruptiblePowerSupplyEfficiency_5068Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Efficiency() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getUninterruptiblePowerSupply_Efficiency() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			parser.setViewPattern("Efficiency: {0}"); //$NON-NLS-1$
			parser.setEditorPattern("Efficiency: {0}"); //$NON-NLS-1$
			parser.setEditPattern("Efficiency: {0}"); //$NON-NLS-1$
			uninterruptiblePowerSupplyEfficiency_5068Parser = parser;
		}
		return uninterruptiblePowerSupplyEfficiency_5068Parser;
	}

	/**
	 * @generated
	 */
	private IParser roomName_5069Parser;

	/**
	 * @generated
	 */
	private IParser getRoomName_5069Parser() {
		if (roomName_5069Parser == null) {
			EAttribute[] features = new EAttribute[] { PAMPackage.eINSTANCE
					.getRoom_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { PAMPackage.eINSTANCE
					.getRoom_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			roomName_5069Parser = parser;
		}
		return roomName_5069Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case NetworkNodeNameEditPart.VISUAL_ID:
			return getNetworkNodeName_5039Parser();
		case NetworkNodeMax_WattEditPart.VISUAL_ID:
			return getNetworkNodeMax_Watt_5040Parser();
		case NetworkNodeMax_ThroughputEditPart.VISUAL_ID:
			return getNetworkNodeMax_Throughput_5041Parser();
		case ServerNodeNameEditPart.VISUAL_ID:
			return getServerNodeName_5042Parser();
		case ServerNodeMax_WattEditPart.VISUAL_ID:
			return getServerNodeMax_Watt_5043Parser();
		case ServerNodeIdle_WattEditPart.VISUAL_ID:
			return getServerNodeIdle_Watt_5044Parser();
		case ServerNodeAct_WattEditPart.VISUAL_ID:
			return getServerNodeAct_Watt_5045Parser();
		case ServerNodeMax_CapacityEditPart.VISUAL_ID:
			return getServerNodeMax_Capacity_5046Parser();
		case ServerNodeMFLOPsEditPart.VISUAL_ID:
			return getServerNodeMFLOPs_5047Parser();
		case ClientNodeNameEditPart.VISUAL_ID:
			return getClientNodeName_5048Parser();
		case ClientNodeMax_WattEditPart.VISUAL_ID:
			return getClientNodeMax_Watt_5049Parser();
		case ClientNodeMFLOPsEditPart.VISUAL_ID:
			return getClientNodeMFLOPs_5050Parser();
		case RoomNameEditPart.VISUAL_ID:
			return getRoomName_5070Parser();
		case CoolingNameEditPart.VISUAL_ID:
			return getCoolingName_5071Parser();
		case CoolingMax_WattEditPart.VISUAL_ID:
			return getCoolingMax_Watt_5072Parser();
		case CoolingCooling_CapacityEditPart.VISUAL_ID:
			return getCoolingCooling_Capacity_5073Parser();
		case UninterruptiblePowerSupplyNameEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyName_5074Parser();
		case UninterruptiblePowerSupplyOut_WattEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyOut_Watt_5075Parser();
		case UninterruptiblePowerSupplyEfficiencyEditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyEfficiency_5076Parser();
		case ClientNodeName2EditPart.VISUAL_ID:
			return getClientNodeName_5051Parser();
		case ClientNodeMax_Watt2EditPart.VISUAL_ID:
			return getClientNodeMax_Watt_5052Parser();
		case ClientNodeMFLOPs2EditPart.VISUAL_ID:
			return getClientNodeMFLOPs_5053Parser();
		case ServerNodeName2EditPart.VISUAL_ID:
			return getServerNodeName_5054Parser();
		case ServerNodeMax_Watt2EditPart.VISUAL_ID:
			return getServerNodeMax_Watt_5055Parser();
		case ServerNodeIdle_Watt2EditPart.VISUAL_ID:
			return getServerNodeIdle_Watt_5056Parser();
		case ServerNodeAct_Watt2EditPart.VISUAL_ID:
			return getServerNodeAct_Watt_5057Parser();
		case ServerNodeMax_Capacity2EditPart.VISUAL_ID:
			return getServerNodeMax_Capacity_5058Parser();
		case ServerNodeMFLOPs2EditPart.VISUAL_ID:
			return getServerNodeMFLOPs_5059Parser();
		case NetworkNodeName2EditPart.VISUAL_ID:
			return getNetworkNodeName_5060Parser();
		case NetworkNodeMax_Watt2EditPart.VISUAL_ID:
			return getNetworkNodeMax_Watt_5061Parser();
		case NetworkNodeMax_Throughput2EditPart.VISUAL_ID:
			return getNetworkNodeMax_Throughput_5062Parser();
		case CoolingName2EditPart.VISUAL_ID:
			return getCoolingName_5063Parser();
		case CoolingMax_Watt2EditPart.VISUAL_ID:
			return getCoolingMax_Watt_5064Parser();
		case CoolingCooling_Capacity2EditPart.VISUAL_ID:
			return getCoolingCooling_Capacity_5065Parser();
		case UninterruptiblePowerSupplyName2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyName_5066Parser();
		case UninterruptiblePowerSupplyOut_Watt2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyOut_Watt_5067Parser();
		case UninterruptiblePowerSupplyEfficiency2EditPart.VISUAL_ID:
			return getUninterruptiblePowerSupplyEfficiency_5068Parser();
		case RoomName2EditPart.VISUAL_ID:
			return getRoomName_5069Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(PAMVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(PAMVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (PAMElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
