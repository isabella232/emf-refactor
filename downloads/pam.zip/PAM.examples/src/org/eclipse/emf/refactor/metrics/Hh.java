package org.eclipse.emf.refactor.metrics;

import java.util.List;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.refactor.metrics.interfaces.IMetricCalculator;
import org.eclipse.emf.refactor.metrics.ocl.managers.OCLManager;


public final class Hh implements IMetricCalculator {

	private final String expression = 
		"(self -> closure(subrooms).includes.Max_Watt -> sum() + self -> closure(subrooms).applies -> iter-ate (w; var:Real = 0 | var + (((w.Out_Watt/w.Efficiency)*100)-w.Out_Watt))+ self -> closure(subrooms).contains.Max_Watt -> sum()) / self -> closure(subrooms).contains.Max_Watt -> sum()";	
	private List<EObject> context; 
		
	@Override
	public void setContext(List<EObject> context) {
		this.context = context;
	}	
		
	@Override
	public double calculate() {	
		EObject contextObject = context.get(0);
		return OCLManager.evaluateOCLOnContextObject(contextObject, expression);
	}
}