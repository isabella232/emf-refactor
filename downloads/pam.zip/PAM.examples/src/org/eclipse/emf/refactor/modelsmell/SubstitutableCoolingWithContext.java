package org.eclipse.emf.refactor.modelsmell;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.refactor.modelsmell.utilities.PAMHelper;
import org.eclipse.emf.refactor.smells.interfaces.IModelSmellFinder;

import pam.refactorings.Optimizer;
import PAM.Cooling;

public class SubstitutableCoolingWithContext implements IModelSmellFinder {

	@Override
	public LinkedList<LinkedList<EObject>> findSmell(EObject root) {
		LinkedList<LinkedList<EObject>> results = new LinkedList<LinkedList<EObject>>();
		// custom code
		List<EObject> allCoolings = PAMHelper.getAllCoolings(root);
		for (EObject cooling : allCoolings) {
			if (! Optimizer.getBetterCoolingWithContext((Cooling) cooling).isEmpty()) {
				LinkedList<EObject> result = new LinkedList<EObject>();
				result.add(cooling);
				results.add(result);
			}
		}
		// end custom code
		return results;
	}

}
