package org.eclipse.emf.refactor.modelsmell.utilities;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;

import PAM.ClientNode;
import PAM.Cooling;
import PAM.NetworkNode;
import PAM.ServerNode;
import PAM.UninterruptiblePowerSupply;

public class PAMHelper {

	public static List<EObject> getAllCoolings(EObject root) {
		List<EObject> allCoolings = new ArrayList<EObject>();
		TreeIterator<EObject> iter = root.eAllContents();
		while (iter.hasNext()) {
			EObject eObject = iter.next();
			if (eObject instanceof Cooling) {
				allCoolings.add((Cooling) eObject);
			}
		}
		return allCoolings;
	}

	public static List<EObject> getAllServerNodes(EObject root) {
		List<EObject> allServerNodes = new ArrayList<EObject>();
		TreeIterator<EObject> iter = root.eAllContents();
		while (iter.hasNext()) {
			EObject eObject = iter.next();
			if (eObject instanceof ServerNode) {
				allServerNodes.add((ServerNode) eObject);
			}
		}
		return allServerNodes;
	}

	public static List<EObject> getAllClientNodes(EObject root) {
		List<EObject> allClientNodes = new ArrayList<EObject>();
		TreeIterator<EObject> iter = root.eAllContents();
		while (iter.hasNext()) {
			EObject eObject = iter.next();
			if (eObject instanceof ClientNode) {
				allClientNodes.add((ClientNode) eObject);
			}
		}
		return allClientNodes;
	}

	public static List<EObject> getAllNetworkNodes(EObject root) {
		List<EObject> allNetworkNodes = new ArrayList<EObject>();
		TreeIterator<EObject> iter = root.eAllContents();
		while (iter.hasNext()) {
			EObject eObject = iter.next();
			if (eObject instanceof NetworkNode) {
				allNetworkNodes.add((NetworkNode) eObject);
			}
		}
		return allNetworkNodes;
	}

	public static List<EObject> getAllUninterruptiblePowerSupplies(EObject root) {
		List<EObject> allUninterruptiblePowerSupplies = new ArrayList<EObject>();
		TreeIterator<EObject> iter = root.eAllContents();
		while (iter.hasNext()) {
			EObject eObject = iter.next();
			if (eObject instanceof UninterruptiblePowerSupply) {
				allUninterruptiblePowerSupplies.add((UninterruptiblePowerSupply) eObject);
			}
		}
		return allUninterruptiblePowerSupplies;
	}
}
