package pam.refactorings;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EObject;

import PAM.ClientNode;
import PAM.Cooling;
import PAM.NetworkNode;
import PAM.NetworkObjectLink;
import PAM.Nodes;
import PAM.Room;
import PAM.ServerNode;
import PAM.UninterruptiblePowerSupply;

public abstract class Optimizer {

	public static List<ClientNode> getBetterClientNodes(ClientNode client) {
		List<ClientNode> clientNodes = new ArrayList<ClientNode>();
		for (TreeIterator<EObject> iter = client.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof ClientNode) {
				ClientNode clientNode = (ClientNode) eObject;
				if (clientNode != client
						&& isEnergeticImprovement(clientNode, client)
						&& hasAtLeastSameFunctionality(clientNode, client)) {
					clientNodes.add(clientNode);
				}
			}
		}	
		return clientNodes;
	}
	
	public static List<ServerNode> getBetterServerNodes(ServerNode server) {
		List<ServerNode> serverNodes = new ArrayList<ServerNode>();
		for (TreeIterator<EObject> iter = server.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof ServerNode) {
				ServerNode serverNode = (ServerNode) eObject;
				if (serverNode != server
						&& isEnergeticImprovement(serverNode, server)
						&& hasAtLeastSameFunctionality(serverNode, server)) {
					serverNodes.add(serverNode);
				}
			}
		}
		return serverNodes;
	}
	
	public static List<NetworkNode> getBetterNetworkNodes(NetworkNode nwNode) {
		List<NetworkNode> networkNodes = new ArrayList<NetworkNode>();
		for (TreeIterator<EObject> iter = nwNode.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof NetworkNode) {
				NetworkNode networkNode = (NetworkNode) eObject;
				if (networkNode != nwNode
						&& isEnergeticImprovement(networkNode, nwNode)
						&& hasAtLeastSameFunctionality(networkNode, nwNode)) {
					networkNodes.add(networkNode);
				}
			}
		}
		return networkNodes;
	}
	
	public static List<UninterruptiblePowerSupply> getBetterUPSwithoutContext(UninterruptiblePowerSupply ups) {
		List<UninterruptiblePowerSupply> upss = new ArrayList<UninterruptiblePowerSupply>();
		for (TreeIterator<EObject> iter = ups.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof UninterruptiblePowerSupply) {
				UninterruptiblePowerSupply uninterruptiblePowerSupply = (UninterruptiblePowerSupply) eObject;
				if (uninterruptiblePowerSupply != ups
						&& isEnergeticImprovement(uninterruptiblePowerSupply, ups)
						&& hasAtLeastSameFunctionality(uninterruptiblePowerSupply, ups)) {
					upss.add(uninterruptiblePowerSupply);
				}
			}
		}
		return upss;
	}

	public static List<UninterruptiblePowerSupply> getBetterUPSwithContext(UninterruptiblePowerSupply ups) {
		List<UninterruptiblePowerSupply> upss = new ArrayList<UninterruptiblePowerSupply>();
		for (TreeIterator<EObject> iter = ups.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof UninterruptiblePowerSupply) {
				UninterruptiblePowerSupply uninterruptiblePowerSupply = (UninterruptiblePowerSupply) eObject;
				if (uninterruptiblePowerSupply != ups
						&& isEnergeticImprovement(uninterruptiblePowerSupply, ups)
						&& hasRequiredFunctionality(uninterruptiblePowerSupply, ups)) {
					upss.add(uninterruptiblePowerSupply);
				}
			}
		}
		return upss;
	}

	public static List<Cooling> getBetterCoolingWithoutContext(Cooling cooling) {
		List<Cooling> coolings = new ArrayList<Cooling>();
		for (TreeIterator<EObject> iter = cooling.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof Cooling) {
				Cooling c = (Cooling) eObject; 
				if (c != cooling
						&& isEnergeticImprovement(c, cooling)
						&& hasAtLeastSameFunctionality(c, cooling)) {
					coolings.add(c);
				}
			}
		}
		return coolings;
	}

	public static List<Cooling> getBetterCoolingWithContext(Cooling cooling) {
		List<Cooling> coolings = new ArrayList<Cooling>();
		for (TreeIterator<EObject> iter = cooling.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof Cooling) {
				Cooling c = (Cooling) eObject; 
				if (c != cooling
						&& isEnergeticImprovement(c, cooling)
						&& hasRequiredFunctionality(c, cooling)) {
					coolings.add(c);
				}
			}
		}
		return coolings;
	}

	public static List<ClientNode> getOptimalClientNodes(ClientNode client) {
		List<ClientNode> optimalClientNodes = new ArrayList<ClientNode>();
		List<ClientNode> clientNodes = getBetterClientNodes(client);
		for (ClientNode cn : clientNodes) {
			boolean isOptimal = true;
			for (ClientNode candidate : clientNodes) {
				if (cn != candidate && isEnergeticImprovement(candidate, cn)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalClientNodes.add(cn);
			}
		}
		return optimalClientNodes;
	}
	
	public static List<ServerNode> getOptimalServerNodes(ServerNode server) {
		List<ServerNode> optimalServerNodes = new ArrayList<ServerNode>();
		List<ServerNode> serverNodes = getBetterServerNodes(server);
		for (ServerNode sn : serverNodes) {
			boolean isOptimal = true;
			for (ServerNode candidate : serverNodes) {
				if (sn != candidate && isEnergeticImprovement(candidate, sn)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalServerNodes.add(sn);
			}
		}
		return optimalServerNodes;
	}
	
	public static List<UninterruptiblePowerSupply> getOptimalUPSwithoutContext(UninterruptiblePowerSupply ups) {
		List<UninterruptiblePowerSupply> optimalUninterruptiblePowerSupplys = new ArrayList<UninterruptiblePowerSupply>();
		List<UninterruptiblePowerSupply> upss = getBetterUPSwithoutContext(ups);
		for (UninterruptiblePowerSupply unintPS : upss) {
			boolean isOptimal = true;
			for (UninterruptiblePowerSupply candidate : upss) {
				if (unintPS != candidate && isEnergeticImprovement(candidate, unintPS)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalUninterruptiblePowerSupplys.add(unintPS);
			}
		}
		return optimalUninterruptiblePowerSupplys;
	}
	
	public static List<Cooling> getOptimalCoolingWithoutContext(Cooling cooling) {
		List<Cooling> optimalCoolings = new ArrayList<Cooling>();
		List<Cooling> coolings = getBetterCoolingWithoutContext(cooling);
		for (Cooling c : coolings) {
			boolean isOptimal = true;
			for (Cooling candidate : coolings) {
				if (c != candidate && isEnergeticImprovement(candidate, c)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalCoolings.add(c);
			}
		}
		return optimalCoolings;
	}
	
	public static List<Cooling> getOptimalCoolingWithContext(Cooling cooling) {
		List<Cooling> optimalCoolings = new ArrayList<Cooling>();
		List<Cooling> coolings = getBetterCoolingWithContext(cooling);
		for (Cooling c : coolings) {
			boolean isOptimal = true;
			for (Cooling candidate : coolings) {
				if (c != candidate && isEnergeticImprovement(candidate, c)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalCoolings.add(c);
			}
		}
		return optimalCoolings;
	}
	
	public static List<UninterruptiblePowerSupply> getOptimalUPSwithContext(UninterruptiblePowerSupply ups) {
		List<UninterruptiblePowerSupply> optimalUninterruptiblePowerSupplys = new ArrayList<UninterruptiblePowerSupply>();
		List<UninterruptiblePowerSupply> upss = getBetterUPSwithContext(ups);
		for (UninterruptiblePowerSupply unintPS : upss) {
			boolean isOptimal = true;
			for (UninterruptiblePowerSupply candidate : upss) {
				if (unintPS != candidate && isEnergeticImprovement(candidate, unintPS)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalUninterruptiblePowerSupplys.add(unintPS);
			}
		}
		return optimalUninterruptiblePowerSupplys;
	}
	
	public static List<NetworkNode> getOptimalNetworkNodes(NetworkNode network) {
		List<NetworkNode> optimalNetworkNodes = new ArrayList<NetworkNode>();
		List<NetworkNode> networkNodes = getBetterNetworkNodes(network);
		for (NetworkNode node : networkNodes) {
			boolean isOptimal = true;
			for (NetworkNode candidate : networkNodes) {
				if (node != candidate && isEnergeticImprovement(candidate, node)) {
					isOptimal = false;
					break;
				}
			}
			if (isOptimal) {
				optimalNetworkNodes.add(node);
			}
		}
		return optimalNetworkNodes;
	}
	
	private static boolean hasAtLeastSameFunctionality(ClientNode candidate, ClientNode client) {
		return candidate.getMFLOPs() >= client.getMFLOPs();
	}
	
	private static boolean hasAtLeastSameFunctionality(ServerNode candidate, ServerNode server) {
		return candidate.getMFLOPs() >= server.getMFLOPs() && candidate.getMax_Capacity() >= server.getMax_Capacity();
	}
	
	private static boolean hasAtLeastSameFunctionality(NetworkNode candidate, NetworkNode nwNode) {
		return numberOfIncomingLinks(candidate) >= numberOfIncomingLinks(nwNode) && candidate.getMax_Throughput() >= nwNode.getMax_Throughput();
	}
	
	private static boolean hasAtLeastSameFunctionality(UninterruptiblePowerSupply candidate, UninterruptiblePowerSupply ups) {
		return candidate.getOut_Watt() >= ups.getOut_Watt();
	}
	
	private static boolean hasAtLeastSameFunctionality(Cooling candidate, Cooling cooling) {
		return candidate.getCooling_Capacity() >= cooling.getCooling_Capacity();
	}

	private static boolean hasRequiredFunctionality(UninterruptiblePowerSupply candidate, UninterruptiblePowerSupply ups) {
		Room room = getOwningRoom(ups);		
		return getRequiredMaxWatt(room) <= candidate.getOut_Watt();
	}

	private static boolean hasRequiredFunctionality(Cooling candidate, Cooling cooling) {
		Room room = getOwningRoom(cooling);		
		return getRequiredMaxWatt(room) <= candidate.getCooling_Capacity();
	}
	
	@SuppressWarnings("unchecked")
	public static int getRequiredMaxWatt(Room room) {
		int requiredMaxWatt = 0;
		List<Room> allRooms = getAllRooms(room);
		for (Room r : allRooms) {
			EList<Nodes> nodes = r.getContains();
			for (Nodes n : nodes) {
				requiredMaxWatt += n.getMax_Watt();
			}
		}	
		return requiredMaxWatt;
	}
	
	@SuppressWarnings("unchecked")
	public static int getProducedWatt(Room room) {
		int producedWatt = 0;
		EList<UninterruptiblePowerSupply> upss = room.getApplies();
		for (UninterruptiblePowerSupply ups : upss) {
			producedWatt += ups.getOut_Watt();
		}
		return producedWatt;
	}

	@SuppressWarnings("unchecked")
	private static int getCoolingCapacity(Room room) {
		int cc = 0;
		EList<Cooling> coolings = room.getIncludes();
		for (Cooling cooling : coolings) {
			cc += cooling.getCooling_Capacity();
		}
		return cc;
	}
	
	@SuppressWarnings("unchecked")
	private static List<Room> getAllRooms(Room room) {
		List<Room> allRooms = new ArrayList<Room>();
		allRooms.add(room); 
		EList<Room> subrooms = room.getSubrooms();
		for (Room room1 : subrooms) {
			allRooms.addAll(getAllRooms(room1));
		}		
		return allRooms;
	}

	public static Room getOwningRoom(UninterruptiblePowerSupply ups) {
		for (TreeIterator<EObject> iter = ups.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof Room) {
				Room room = (Room) eObject;
				if (room.getApplies().contains(ups)) return room;
			}
		}
		return null;
	}
	
	public static Room getOwningRoom(Cooling cooling) {
		for (TreeIterator<EObject> iter = cooling.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof Room) {
				Room room = (Room) eObject;
				if (room.getIncludes().contains(cooling)) return room;
			}
		}
		return null;
	}

	private static int numberOfIncomingLinks(NetworkNode nwNode) {
		int numberOfIncomingLinks = 0;
		for (TreeIterator<EObject> iter = nwNode.eResource().getAllContents(); iter.hasNext(); ) {
			EObject eObject = (EObject) iter.next();
			if (eObject instanceof NetworkObjectLink) {
				NetworkObjectLink networkObjectLink = (NetworkObjectLink) eObject;
				if (networkObjectLink.getConnect0() == nwNode) numberOfIncomingLinks++;
				if (networkObjectLink.getConnect1() == nwNode) numberOfIncomingLinks++;
			}
		}
		return numberOfIncomingLinks;
	}

	private static boolean isEnergeticImprovement(ClientNode candidate, ClientNode node) {
		return candidate.getMax_Watt() < node.getMax_Watt();
	}
	
	private static boolean isEnergeticImprovement(ServerNode candidate, ServerNode node) {
		boolean efficiency1 = (candidate.getMax_Watt() < node.getMax_Watt())
				&& (candidate.getAct_Watt() <= node.getAct_Watt())
				&& (candidate.getIdle_Watt() <= node.getIdle_Watt());
		boolean efficiency2 = (candidate.getMax_Watt() <= node.getMax_Watt())
				&& (candidate.getAct_Watt() < node.getAct_Watt())
				&& (candidate.getIdle_Watt() <= node.getIdle_Watt());
		boolean efficiency3 = (candidate.getMax_Watt() <= node.getMax_Watt())
				&& (candidate.getAct_Watt() <= node.getAct_Watt())
				&& (candidate.getIdle_Watt() < node.getIdle_Watt());
		return efficiency1 || efficiency2 || efficiency3;
	}
	
	private static boolean isEnergeticImprovement(NetworkNode candidate, NetworkNode node) {
		return candidate.getMax_Watt() < node.getMax_Watt();
	}
	
	private static boolean isEnergeticImprovement(UninterruptiblePowerSupply candidate, UninterruptiblePowerSupply ups) {
		return getEfficiency(candidate) < getEfficiency(ups);
	}

	private static boolean isEnergeticImprovement(Cooling candidate, Cooling cooling) {
		return candidate.getMax_Watt() < cooling.getMax_Watt();
	}

	private static double getEfficiency(UninterruptiblePowerSupply ups) {
		return (((ups.getOut_Watt()/ups.getEfficiency())*100) - ups.getOut_Watt());
	}

	public static boolean isDeletable(UninterruptiblePowerSupply ups) {
		Room owningRoom = getOwningRoom(ups);
		int requiredWatt = getRequiredMaxWatt(owningRoom);
		int producedWatt = getProducedWatt(owningRoom);
		return (requiredWatt <=  (producedWatt - ups.getOut_Watt()));
	}

	public static boolean isDeletable(Cooling cooling) {
		Room owningRoom = getOwningRoom(cooling);
		int requiredWatt = getRequiredMaxWatt(owningRoom);
		int coolingCapacity = getCoolingCapacity(owningRoom);
		return (requiredWatt <=  (coolingCapacity - cooling.getCooling_Capacity()));
	}

	@SuppressWarnings("unchecked")
	public static boolean isOptimalDeletable(UninterruptiblePowerSupply ups) {
		if (isDeletable(ups)) {
			Room owningRoom = getOwningRoom(ups);
			EList<UninterruptiblePowerSupply> upss = owningRoom.getApplies();
			for (UninterruptiblePowerSupply candidate : upss) {
				if (candidate != ups && isDeletable(candidate) && isEnergeticImprovement(ups, candidate)) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public static boolean isOptimalDeletable(Cooling cooling) {
		if (isDeletable(cooling)) {
			Room owningRoom = getOwningRoom(cooling);
			EList<Cooling> coolings = owningRoom.getIncludes();
			for (Cooling candidate : coolings) {
				if (candidate != cooling && isDeletable(candidate) && isEnergeticImprovement(cooling, candidate)) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

}
