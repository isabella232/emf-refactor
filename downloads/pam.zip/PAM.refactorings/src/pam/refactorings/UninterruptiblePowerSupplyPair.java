package pam.refactorings;

import PAM.UninterruptiblePowerSupply;

public class UninterruptiblePowerSupplyPair {
	
	private UninterruptiblePowerSupply ups1, ups2;

	public UninterruptiblePowerSupply getUps1() {
		return ups1;
	}

	public UninterruptiblePowerSupply getUps2() {
		return ups2;
	}

	public UninterruptiblePowerSupplyPair(UninterruptiblePowerSupply ups1,
			UninterruptiblePowerSupply ups2) {
		super();
		this.ups1 = ups1;
		this.ups2 = ups2;
	}

	@Override
	public String toString() {
		return "<" + ups1.getName() + ", " + ups2.getName() + ">";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (! (obj instanceof UninterruptiblePowerSupplyPair)) return false;
		UninterruptiblePowerSupplyPair pair = (UninterruptiblePowerSupplyPair) obj;
		return ((this.ups1.equals(pair.ups1) && this.ups2.equals(pair.ups2)) 
				|| (this.ups1.equals(pair.ups2) && this.ups2.equals(pair.ups1)));
	}
}
