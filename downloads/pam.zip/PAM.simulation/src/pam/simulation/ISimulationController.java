package pam.simulation;

public interface ISimulationController {
	
	public void setParameters();
}
