package pam.simulation;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.refactor.refactoring.core.Refactoring;
import org.eclipse.emf.refactor.refactoring.runtime.ltk.LtkEmfRefactoringProcessorAdapter;
import org.eclipse.emf.refactor.smells.configuration.managers.ConfigurationManager;
import org.eclipse.emf.refactor.smells.core.MetricBasedModelSmellFinderClass;
import org.eclipse.emf.refactor.smells.core.ModelSmell;
import org.eclipse.emf.refactor.smells.runtime.core.EObjectGroup;
import org.eclipse.emf.refactor.smells.runtime.core.ModelSmellFinder;
import org.eclipse.emf.refactor.smells.runtime.core.Result;
import org.eclipse.emf.refactor.smells.eraser.managers.EraseManager;
import org.eclipse.jface.dialogs.MessageDialog;

public class Simulator {
	
	private static LinkedList<Result> results = new LinkedList<Result>();
	private static Map<Refactoring, Set<EObject>> applicableRefactorings = 
			new HashMap<Refactoring, Set<EObject>>();
	
	public static void simulate(IProject project, EObject root, int stop) {
		results = searchSmells(project, root);
		if ((! results.isEmpty()) && (results.size() != stop)) {
			for (Result result: results) {
				for (LinkedList<EObject> smellOccurrence : result.getModelelements()) {
					EObjectGroup group = new EObjectGroup(result.getSmell(), smellOccurrence);
					applicableRefactorings = EraseManager.getApplicableRefactoringsDynamically(group);
					if (! applicableRefactorings.isEmpty()) {
						Refactoring refactoring = null;
						for (Refactoring ref : applicableRefactorings.keySet()) {
							if (ref.getId().endsWith(".opt")) {
								refactoring = ref;
								break;
							}
						}
						if (refactoring != null) {
							((ISimulationController) refactoring.getController()).setParameters();
							LtkEmfRefactoringProcessorAdapter processor = (LtkEmfRefactoringProcessorAdapter) 
									refactoring.getController().getLtkRefactoringProcessor();
							if (processor.checkConditions()) {
								try {
									processor.createChange(new NullProgressMonitor()).perform(new NullProgressMonitor());
								} catch (OperationCanceledException e) {
									MessageDialog.openError(null, "PAM Simulation", e.getMessage());
									e.printStackTrace();
								} catch (CoreException e) {
									MessageDialog.openError(null, "PAM Simulation", e.getMessage());
									e.printStackTrace();
								}
							}
						}
					}					
				}				
			}
			simulate(project, root, results.size());
		}		
	}

	private static LinkedList<Result> searchSmells(IProject project, EObject root) {
		LinkedList<Result> results = new LinkedList<Result>();
		ConfigurationManager.getInstance();
		LinkedList<ModelSmell> smells = ConfigurationManager.getSelectedModelSmells(project);
		for(ModelSmell smell : smells){
			if(smell.getFinderClass() instanceof MetricBasedModelSmellFinderClass)
				((MetricBasedModelSmellFinderClass)smell.getFinderClass()).setLimit(ConfigurationManager.getLimit(project, smell.getId()));
		}
		LinkedList<Result> resultsTmp = ModelSmellFinder.findModelSmells(smells, root);
		for (Result result: resultsTmp) {
			if (! result.getModelelements().isEmpty()) {
				results.add(result);
			}
		}
		return results;
	}
}
