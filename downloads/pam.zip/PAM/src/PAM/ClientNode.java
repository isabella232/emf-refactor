/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Client Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.ClientNode#getMFLOPs <em>MFLO Ps</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getClientNode()
 * @model
 * @generated
 */
public interface ClientNode extends Nodes, Comparable {
	/**
	 * Returns the value of the '<em><b>MFLO Ps</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>MFLO Ps</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>MFLO Ps</em>' attribute.
	 * @see #setMFLOPs(int)
	 * @see PAM.PAMPackage#getClientNode_MFLOPs()
	 * @model
	 * @generated
	 */
	int getMFLOPs();

	/**
	 * Sets the value of the '{@link PAM.ClientNode#getMFLOPs <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>MFLO Ps</em>' attribute.
	 * @see #getMFLOPs()
	 * @generated
	 */
	void setMFLOPs(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/GenModel body='\r\nClientNode client1 = (ClientNode) o;\r\n\t\t\r\nif (getMax_Watt() < client1.getMax_Watt()) {\r\n\treturn -1;\r\n}\r\n\r\nif (getMax_Watt() == client1.getMax_Watt()) {\r\n\treturn 0;\r\n}\r\n\r\nif (client1.compareTo(this) == -1) {\r\n\treturn 1;\r\n}\r\n\r\nreturn 0;\r\n'"
	 * @generated
	 */
	int compareTo(Object o);

} // ClientNode
