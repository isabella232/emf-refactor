/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cooling</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.Cooling#getMax_Watt <em>Max Watt</em>}</li>
 *   <li>{@link PAM.Cooling#getName <em>Name</em>}</li>
 *   <li>{@link PAM.Cooling#getCooling_Capacity <em>Cooling Capacity</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getCooling()
 * @model
 * @generated
 */
public interface Cooling extends EObject, Comparable {
	/**
	 * Returns the value of the '<em><b>Max Watt</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Watt</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Watt</em>' attribute.
	 * @see #setMax_Watt(int)
	 * @see PAM.PAMPackage#getCooling_Max_Watt()
	 * @model default="0"
	 * @generated
	 */
	int getMax_Watt();

	/**
	 * Sets the value of the '{@link PAM.Cooling#getMax_Watt <em>Max Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Watt</em>' attribute.
	 * @see #getMax_Watt()
	 * @generated
	 */
	void setMax_Watt(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PAM.PAMPackage#getCooling_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PAM.Cooling#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Cooling Capacity</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cooling Capacity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cooling Capacity</em>' attribute.
	 * @see #setCooling_Capacity(int)
	 * @see PAM.PAMPackage#getCooling_Cooling_Capacity()
	 * @model default="0"
	 * @generated
	 */
	int getCooling_Capacity();

	/**
	 * Sets the value of the '{@link PAM.Cooling#getCooling_Capacity <em>Cooling Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cooling Capacity</em>' attribute.
	 * @see #getCooling_Capacity()
	 * @generated
	 */
	void setCooling_Capacity(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/GenModel body='\r\nCooling client1 = (Cooling) o;\r\n\r\nif (getMax_Watt() < client1.getMax_Watt()) {\r\n\treturn -1;\r\n}\r\n\r\nif (getMax_Watt() == client1.getMax_Watt()) {\r\n\treturn 0;\r\n}\r\n\r\nif (client1.compareTo(this) == -1) {\r\n\treturn 1;\r\n}\r\n\t\t\r\nreturn 0;\r\n'"
	 * @generated
	 */
	int compareTo(Object o);

} // Cooling
