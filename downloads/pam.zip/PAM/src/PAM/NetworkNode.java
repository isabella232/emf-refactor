/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.NetworkNode#getMax_Throughput <em>Max Throughput</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getNetworkNode()
 * @model
 * @generated
 */
public interface NetworkNode extends Nodes, Comparable {
	/**
	 * Returns the value of the '<em><b>Max Throughput</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Throughput</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Throughput</em>' attribute.
	 * @see #setMax_Throughput(int)
	 * @see PAM.PAMPackage#getNetworkNode_Max_Throughput()
	 * @model
	 * @generated
	 */
	int getMax_Throughput();

	/**
	 * Sets the value of the '{@link PAM.NetworkNode#getMax_Throughput <em>Max Throughput</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Throughput</em>' attribute.
	 * @see #getMax_Throughput()
	 * @generated
	 */
	void setMax_Throughput(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/GenModel body='\r\nNetworkNode Network1 = (NetworkNode) o;\r\n\r\nif ((getMax_Watt() < Network1.getMax_Watt()) || (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() < Network1.getMax_Throughput())) {\r\n\treturn -1;\r\n}\r\n\r\nif (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() == Network1.getMax_Throughput()) {\r\n\treturn 0;\r\n}\r\n\r\nif ((getMax_Watt() > Network1.getMax_Watt()) || (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() > Network1.getMax_Throughput())) {\r\n\treturn 1;\r\n}\r\n\t\t\r\nreturn 0;\r\n'"
	 * @generated
	 */
	int compareTo(Object o);

} // NetworkNode
