/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Object Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.NetworkObjectLink#getConnect0 <em>Connect0</em>}</li>
 *   <li>{@link PAM.NetworkObjectLink#getConnect1 <em>Connect1</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getNetworkObjectLink()
 * @model
 * @generated
 */
public interface NetworkObjectLink extends EObject {
	/**
	 * Returns the value of the '<em><b>Connect0</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connect0</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connect0</em>' reference.
	 * @see #setConnect0(Nodes)
	 * @see PAM.PAMPackage#getNetworkObjectLink_Connect0()
	 * @model required="true"
	 * @generated
	 */
	Nodes getConnect0();

	/**
	 * Sets the value of the '{@link PAM.NetworkObjectLink#getConnect0 <em>Connect0</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connect0</em>' reference.
	 * @see #getConnect0()
	 * @generated
	 */
	void setConnect0(Nodes value);

	/**
	 * Returns the value of the '<em><b>Connect1</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connect1</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connect1</em>' reference.
	 * @see #setConnect1(NetworkNode)
	 * @see PAM.PAMPackage#getNetworkObjectLink_Connect1()
	 * @model required="true"
	 * @generated
	 */
	NetworkNode getConnect1();

	/**
	 * Sets the value of the '{@link PAM.NetworkObjectLink#getConnect1 <em>Connect1</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connect1</em>' reference.
	 * @see #getConnect1()
	 * @generated
	 */
	void setConnect1(NetworkNode value);

} // NetworkObjectLink
