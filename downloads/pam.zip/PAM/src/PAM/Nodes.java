/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Nodes</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.Nodes#getName <em>Name</em>}</li>
 *   <li>{@link PAM.Nodes#getMax_Watt <em>Max Watt</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getNodes()
 * @model abstract="true"
 * @generated
 */
public interface Nodes extends EObject  {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PAM.PAMPackage#getNodes_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PAM.Nodes#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Watt</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Watt</em>' attribute.
	 * @see #setMax_Watt(int)
	 * @see PAM.PAMPackage#getNodes_Max_Watt()
	 * @model
	 * @generated
	 */
	int getMax_Watt();

	/**
	 * Sets the value of the '{@link PAM.Nodes#getMax_Watt <em>Max Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Watt</em>' attribute.
	 * @see #getMax_Watt()
	 * @generated
	 */
	void setMax_Watt(int value);

} // Nodes
