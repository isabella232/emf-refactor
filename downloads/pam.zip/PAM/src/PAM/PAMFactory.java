/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see PAM.PAMPackage
 * @generated
 */
public interface PAMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PAMFactory eINSTANCE = PAM.impl.PAMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Network Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Network Node</em>'.
	 * @generated
	 */
	NetworkNode createNetworkNode();

	/**
	 * Returns a new object of class '<em>Server Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Server Node</em>'.
	 * @generated
	 */
	ServerNode createServerNode();

	/**
	 * Returns a new object of class '<em>Client Node</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Client Node</em>'.
	 * @generated
	 */
	ClientNode createClientNode();

	/**
	 * Returns a new object of class '<em>Network Object Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Network Object Link</em>'.
	 * @generated
	 */
	NetworkObjectLink createNetworkObjectLink();

	/**
	 * Returns a new object of class '<em>Room</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Room</em>'.
	 * @generated
	 */
	Room createRoom();

	/**
	 * Returns a new object of class '<em>Cooling</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cooling</em>'.
	 * @generated
	 */
	Cooling createCooling();

	/**
	 * Returns a new object of class '<em>Uninterruptible Power Supply</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Uninterruptible Power Supply</em>'.
	 * @generated
	 */
	UninterruptiblePowerSupply createUninterruptiblePowerSupply();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PAMPackage getPAMPackage();

} //PAMFactory
