/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see PAM.PAMFactory
 * @model kind="package"
 * @generated
 */
public interface PAMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PAM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "PAM";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "PAM";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PAMPackage eINSTANCE = PAM.impl.PAMPackageImpl.init();

	/**
	 * The meta object id for the '{@link PAM.impl.NodesImpl <em>Nodes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.NodesImpl
	 * @see PAM.impl.PAMPackageImpl#getNodes()
	 * @generated
	 */
	int NODES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODES__NAME = 0;

	/**
	 * The feature id for the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODES__MAX_WATT = 1;

	/**
	 * The number of structural features of the '<em>Nodes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODES_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link PAM.impl.NetworkNodeImpl <em>Network Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.NetworkNodeImpl
	 * @see PAM.impl.PAMPackageImpl#getNetworkNode()
	 * @generated
	 */
	int NETWORK_NODE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_NODE__NAME = NODES__NAME;

	/**
	 * The feature id for the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_NODE__MAX_WATT = NODES__MAX_WATT;

	/**
	 * The feature id for the '<em><b>Max Throughput</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_NODE__MAX_THROUGHPUT = NODES_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Network Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_NODE_FEATURE_COUNT = NODES_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link PAM.impl.ServerNodeImpl <em>Server Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.ServerNodeImpl
	 * @see PAM.impl.PAMPackageImpl#getServerNode()
	 * @generated
	 */
	int SERVER_NODE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__NAME = NODES__NAME;

	/**
	 * The feature id for the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__MAX_WATT = NODES__MAX_WATT;

	/**
	 * The feature id for the '<em><b>Max Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__MAX_CAPACITY = NODES_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Idle Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__IDLE_WATT = NODES_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Act Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__ACT_WATT = NODES_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>MFLO Ps</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE__MFLO_PS = NODES_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Server Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_NODE_FEATURE_COUNT = NODES_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link PAM.impl.ClientNodeImpl <em>Client Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.ClientNodeImpl
	 * @see PAM.impl.PAMPackageImpl#getClientNode()
	 * @generated
	 */
	int CLIENT_NODE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_NODE__NAME = NODES__NAME;

	/**
	 * The feature id for the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_NODE__MAX_WATT = NODES__MAX_WATT;

	/**
	 * The feature id for the '<em><b>MFLO Ps</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_NODE__MFLO_PS = NODES_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Client Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_NODE_FEATURE_COUNT = NODES_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link PAM.impl.NetworkObjectLinkImpl <em>Network Object Link</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.NetworkObjectLinkImpl
	 * @see PAM.impl.PAMPackageImpl#getNetworkObjectLink()
	 * @generated
	 */
	int NETWORK_OBJECT_LINK = 4;

	/**
	 * The feature id for the '<em><b>Connect0</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_OBJECT_LINK__CONNECT0 = 0;

	/**
	 * The feature id for the '<em><b>Connect1</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_OBJECT_LINK__CONNECT1 = 1;

	/**
	 * The number of structural features of the '<em>Network Object Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_OBJECT_LINK_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link PAM.impl.RoomImpl <em>Room</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.RoomImpl
	 * @see PAM.impl.PAMPackageImpl#getRoom()
	 * @generated
	 */
	int ROOM = 5;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__INCLUDES = 0;

	/**
	 * The feature id for the '<em><b>Applies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__APPLIES = 1;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__CONTAINS = 2;

	/**
	 * The feature id for the '<em><b>Subrooms</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__SUBROOMS = 3;

	/**
	 * The feature id for the '<em><b>Links</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__LINKS = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__NAME = 5;

	/**
	 * The number of structural features of the '<em>Room</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link PAM.impl.CoolingImpl <em>Cooling</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.CoolingImpl
	 * @see PAM.impl.PAMPackageImpl#getCooling()
	 * @generated
	 */
	int COOLING = 6;

	/**
	 * The feature id for the '<em><b>Max Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOLING__MAX_WATT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOLING__NAME = 1;

	/**
	 * The feature id for the '<em><b>Cooling Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOLING__COOLING_CAPACITY = 2;

	/**
	 * The number of structural features of the '<em>Cooling</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOLING_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link PAM.impl.UninterruptiblePowerSupplyImpl <em>Uninterruptible Power Supply</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PAM.impl.UninterruptiblePowerSupplyImpl
	 * @see PAM.impl.PAMPackageImpl#getUninterruptiblePowerSupply()
	 * @generated
	 */
	int UNINTERRUPTIBLE_POWER_SUPPLY = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNINTERRUPTIBLE_POWER_SUPPLY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Out Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT = 1;

	/**
	 * The feature id for the '<em><b>Efficiency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY = 2;

	/**
	 * The number of structural features of the '<em>Uninterruptible Power Supply</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNINTERRUPTIBLE_POWER_SUPPLY_FEATURE_COUNT = 3;


	/**
	 * Returns the meta object for class '{@link PAM.Nodes <em>Nodes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Nodes</em>'.
	 * @see PAM.Nodes
	 * @generated
	 */
	EClass getNodes();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Nodes#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PAM.Nodes#getName()
	 * @see #getNodes()
	 * @generated
	 */
	EAttribute getNodes_Name();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Nodes#getMax_Watt <em>Max Watt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Watt</em>'.
	 * @see PAM.Nodes#getMax_Watt()
	 * @see #getNodes()
	 * @generated
	 */
	EAttribute getNodes_Max_Watt();

	/**
	 * Returns the meta object for class '{@link PAM.NetworkNode <em>Network Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Node</em>'.
	 * @see PAM.NetworkNode
	 * @generated
	 */
	EClass getNetworkNode();

	/**
	 * Returns the meta object for the attribute '{@link PAM.NetworkNode#getMax_Throughput <em>Max Throughput</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Throughput</em>'.
	 * @see PAM.NetworkNode#getMax_Throughput()
	 * @see #getNetworkNode()
	 * @generated
	 */
	EAttribute getNetworkNode_Max_Throughput();

	/**
	 * Returns the meta object for class '{@link PAM.ServerNode <em>Server Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Server Node</em>'.
	 * @see PAM.ServerNode
	 * @generated
	 */
	EClass getServerNode();

	/**
	 * Returns the meta object for the attribute '{@link PAM.ServerNode#getMax_Capacity <em>Max Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Capacity</em>'.
	 * @see PAM.ServerNode#getMax_Capacity()
	 * @see #getServerNode()
	 * @generated
	 */
	EAttribute getServerNode_Max_Capacity();

	/**
	 * Returns the meta object for the attribute '{@link PAM.ServerNode#getIdle_Watt <em>Idle Watt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Idle Watt</em>'.
	 * @see PAM.ServerNode#getIdle_Watt()
	 * @see #getServerNode()
	 * @generated
	 */
	EAttribute getServerNode_Idle_Watt();

	/**
	 * Returns the meta object for the attribute '{@link PAM.ServerNode#getAct_Watt <em>Act Watt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Act Watt</em>'.
	 * @see PAM.ServerNode#getAct_Watt()
	 * @see #getServerNode()
	 * @generated
	 */
	EAttribute getServerNode_Act_Watt();

	/**
	 * Returns the meta object for the attribute '{@link PAM.ServerNode#getMFLOPs <em>MFLO Ps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>MFLO Ps</em>'.
	 * @see PAM.ServerNode#getMFLOPs()
	 * @see #getServerNode()
	 * @generated
	 */
	EAttribute getServerNode_MFLOPs();

	/**
	 * Returns the meta object for class '{@link PAM.ClientNode <em>Client Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Client Node</em>'.
	 * @see PAM.ClientNode
	 * @generated
	 */
	EClass getClientNode();

	/**
	 * Returns the meta object for the attribute '{@link PAM.ClientNode#getMFLOPs <em>MFLO Ps</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>MFLO Ps</em>'.
	 * @see PAM.ClientNode#getMFLOPs()
	 * @see #getClientNode()
	 * @generated
	 */
	EAttribute getClientNode_MFLOPs();

	/**
	 * Returns the meta object for class '{@link PAM.NetworkObjectLink <em>Network Object Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Object Link</em>'.
	 * @see PAM.NetworkObjectLink
	 * @generated
	 */
	EClass getNetworkObjectLink();

	/**
	 * Returns the meta object for the reference '{@link PAM.NetworkObjectLink#getConnect0 <em>Connect0</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connect0</em>'.
	 * @see PAM.NetworkObjectLink#getConnect0()
	 * @see #getNetworkObjectLink()
	 * @generated
	 */
	EReference getNetworkObjectLink_Connect0();

	/**
	 * Returns the meta object for the reference '{@link PAM.NetworkObjectLink#getConnect1 <em>Connect1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connect1</em>'.
	 * @see PAM.NetworkObjectLink#getConnect1()
	 * @see #getNetworkObjectLink()
	 * @generated
	 */
	EReference getNetworkObjectLink_Connect1();

	/**
	 * Returns the meta object for class '{@link PAM.Room <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Room</em>'.
	 * @see PAM.Room
	 * @generated
	 */
	EClass getRoom();

	/**
	 * Returns the meta object for the containment reference list '{@link PAM.Room#getIncludes <em>Includes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Includes</em>'.
	 * @see PAM.Room#getIncludes()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Includes();

	/**
	 * Returns the meta object for the containment reference list '{@link PAM.Room#getApplies <em>Applies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Applies</em>'.
	 * @see PAM.Room#getApplies()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Applies();

	/**
	 * Returns the meta object for the containment reference list '{@link PAM.Room#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Contains</em>'.
	 * @see PAM.Room#getContains()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Contains();

	/**
	 * Returns the meta object for the containment reference list '{@link PAM.Room#getSubrooms <em>Subrooms</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Subrooms</em>'.
	 * @see PAM.Room#getSubrooms()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Subrooms();

	/**
	 * Returns the meta object for the containment reference list '{@link PAM.Room#getLinks <em>Links</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Links</em>'.
	 * @see PAM.Room#getLinks()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Links();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Room#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PAM.Room#getName()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_Name();

	/**
	 * Returns the meta object for class '{@link PAM.Cooling <em>Cooling</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cooling</em>'.
	 * @see PAM.Cooling
	 * @generated
	 */
	EClass getCooling();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Cooling#getMax_Watt <em>Max Watt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Watt</em>'.
	 * @see PAM.Cooling#getMax_Watt()
	 * @see #getCooling()
	 * @generated
	 */
	EAttribute getCooling_Max_Watt();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Cooling#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PAM.Cooling#getName()
	 * @see #getCooling()
	 * @generated
	 */
	EAttribute getCooling_Name();

	/**
	 * Returns the meta object for the attribute '{@link PAM.Cooling#getCooling_Capacity <em>Cooling Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cooling Capacity</em>'.
	 * @see PAM.Cooling#getCooling_Capacity()
	 * @see #getCooling()
	 * @generated
	 */
	EAttribute getCooling_Cooling_Capacity();

	/**
	 * Returns the meta object for class '{@link PAM.UninterruptiblePowerSupply <em>Uninterruptible Power Supply</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Uninterruptible Power Supply</em>'.
	 * @see PAM.UninterruptiblePowerSupply
	 * @generated
	 */
	EClass getUninterruptiblePowerSupply();

	/**
	 * Returns the meta object for the attribute '{@link PAM.UninterruptiblePowerSupply#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see PAM.UninterruptiblePowerSupply#getName()
	 * @see #getUninterruptiblePowerSupply()
	 * @generated
	 */
	EAttribute getUninterruptiblePowerSupply_Name();

	/**
	 * Returns the meta object for the attribute '{@link PAM.UninterruptiblePowerSupply#getOut_Watt <em>Out Watt</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Out Watt</em>'.
	 * @see PAM.UninterruptiblePowerSupply#getOut_Watt()
	 * @see #getUninterruptiblePowerSupply()
	 * @generated
	 */
	EAttribute getUninterruptiblePowerSupply_Out_Watt();

	/**
	 * Returns the meta object for the attribute '{@link PAM.UninterruptiblePowerSupply#getEfficiency <em>Efficiency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Efficiency</em>'.
	 * @see PAM.UninterruptiblePowerSupply#getEfficiency()
	 * @see #getUninterruptiblePowerSupply()
	 * @generated
	 */
	EAttribute getUninterruptiblePowerSupply_Efficiency();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PAMFactory getPAMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link PAM.impl.NodesImpl <em>Nodes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.NodesImpl
		 * @see PAM.impl.PAMPackageImpl#getNodes()
		 * @generated
		 */
		EClass NODES = eINSTANCE.getNodes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODES__NAME = eINSTANCE.getNodes_Name();

		/**
		 * The meta object literal for the '<em><b>Max Watt</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODES__MAX_WATT = eINSTANCE.getNodes_Max_Watt();

		/**
		 * The meta object literal for the '{@link PAM.impl.NetworkNodeImpl <em>Network Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.NetworkNodeImpl
		 * @see PAM.impl.PAMPackageImpl#getNetworkNode()
		 * @generated
		 */
		EClass NETWORK_NODE = eINSTANCE.getNetworkNode();

		/**
		 * The meta object literal for the '<em><b>Max Throughput</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NETWORK_NODE__MAX_THROUGHPUT = eINSTANCE.getNetworkNode_Max_Throughput();

		/**
		 * The meta object literal for the '{@link PAM.impl.ServerNodeImpl <em>Server Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.ServerNodeImpl
		 * @see PAM.impl.PAMPackageImpl#getServerNode()
		 * @generated
		 */
		EClass SERVER_NODE = eINSTANCE.getServerNode();

		/**
		 * The meta object literal for the '<em><b>Max Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVER_NODE__MAX_CAPACITY = eINSTANCE.getServerNode_Max_Capacity();

		/**
		 * The meta object literal for the '<em><b>Idle Watt</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVER_NODE__IDLE_WATT = eINSTANCE.getServerNode_Idle_Watt();

		/**
		 * The meta object literal for the '<em><b>Act Watt</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVER_NODE__ACT_WATT = eINSTANCE.getServerNode_Act_Watt();

		/**
		 * The meta object literal for the '<em><b>MFLO Ps</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVER_NODE__MFLO_PS = eINSTANCE.getServerNode_MFLOPs();

		/**
		 * The meta object literal for the '{@link PAM.impl.ClientNodeImpl <em>Client Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.ClientNodeImpl
		 * @see PAM.impl.PAMPackageImpl#getClientNode()
		 * @generated
		 */
		EClass CLIENT_NODE = eINSTANCE.getClientNode();

		/**
		 * The meta object literal for the '<em><b>MFLO Ps</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLIENT_NODE__MFLO_PS = eINSTANCE.getClientNode_MFLOPs();

		/**
		 * The meta object literal for the '{@link PAM.impl.NetworkObjectLinkImpl <em>Network Object Link</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.NetworkObjectLinkImpl
		 * @see PAM.impl.PAMPackageImpl#getNetworkObjectLink()
		 * @generated
		 */
		EClass NETWORK_OBJECT_LINK = eINSTANCE.getNetworkObjectLink();

		/**
		 * The meta object literal for the '<em><b>Connect0</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NETWORK_OBJECT_LINK__CONNECT0 = eINSTANCE.getNetworkObjectLink_Connect0();

		/**
		 * The meta object literal for the '<em><b>Connect1</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NETWORK_OBJECT_LINK__CONNECT1 = eINSTANCE.getNetworkObjectLink_Connect1();

		/**
		 * The meta object literal for the '{@link PAM.impl.RoomImpl <em>Room</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.RoomImpl
		 * @see PAM.impl.PAMPackageImpl#getRoom()
		 * @generated
		 */
		EClass ROOM = eINSTANCE.getRoom();

		/**
		 * The meta object literal for the '<em><b>Includes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__INCLUDES = eINSTANCE.getRoom_Includes();

		/**
		 * The meta object literal for the '<em><b>Applies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__APPLIES = eINSTANCE.getRoom_Applies();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__CONTAINS = eINSTANCE.getRoom_Contains();

		/**
		 * The meta object literal for the '<em><b>Subrooms</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__SUBROOMS = eINSTANCE.getRoom_Subrooms();

		/**
		 * The meta object literal for the '<em><b>Links</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__LINKS = eINSTANCE.getRoom_Links();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__NAME = eINSTANCE.getRoom_Name();

		/**
		 * The meta object literal for the '{@link PAM.impl.CoolingImpl <em>Cooling</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.CoolingImpl
		 * @see PAM.impl.PAMPackageImpl#getCooling()
		 * @generated
		 */
		EClass COOLING = eINSTANCE.getCooling();

		/**
		 * The meta object literal for the '<em><b>Max Watt</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOLING__MAX_WATT = eINSTANCE.getCooling_Max_Watt();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOLING__NAME = eINSTANCE.getCooling_Name();

		/**
		 * The meta object literal for the '<em><b>Cooling Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOLING__COOLING_CAPACITY = eINSTANCE.getCooling_Cooling_Capacity();

		/**
		 * The meta object literal for the '{@link PAM.impl.UninterruptiblePowerSupplyImpl <em>Uninterruptible Power Supply</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PAM.impl.UninterruptiblePowerSupplyImpl
		 * @see PAM.impl.PAMPackageImpl#getUninterruptiblePowerSupply()
		 * @generated
		 */
		EClass UNINTERRUPTIBLE_POWER_SUPPLY = eINSTANCE.getUninterruptiblePowerSupply();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UNINTERRUPTIBLE_POWER_SUPPLY__NAME = eINSTANCE.getUninterruptiblePowerSupply_Name();

		/**
		 * The meta object literal for the '<em><b>Out Watt</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT = eINSTANCE.getUninterruptiblePowerSupply_Out_Watt();

		/**
		 * The meta object literal for the '<em><b>Efficiency</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY = eINSTANCE.getUninterruptiblePowerSupply_Efficiency();

	}

} //PAMPackage
