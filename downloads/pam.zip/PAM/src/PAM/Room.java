/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.Room#getIncludes <em>Includes</em>}</li>
 *   <li>{@link PAM.Room#getApplies <em>Applies</em>}</li>
 *   <li>{@link PAM.Room#getContains <em>Contains</em>}</li>
 *   <li>{@link PAM.Room#getSubrooms <em>Subrooms</em>}</li>
 *   <li>{@link PAM.Room#getLinks <em>Links</em>}</li>
 *   <li>{@link PAM.Room#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getRoom()
 * @model
 * @generated
 */
public interface Room extends EObject {
	/**
	 * Returns the value of the '<em><b>Includes</b></em>' containment reference list.
	 * The list contents are of type {@link PAM.Cooling}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Includes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Includes</em>' containment reference list.
	 * @see PAM.PAMPackage#getRoom_Includes()
	 * @model type="PAM.Cooling" containment="true"
	 * @generated
	 */
	EList getIncludes();

	/**
	 * Returns the value of the '<em><b>Applies</b></em>' containment reference list.
	 * The list contents are of type {@link PAM.UninterruptiblePowerSupply}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Applies</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Applies</em>' containment reference list.
	 * @see PAM.PAMPackage#getRoom_Applies()
	 * @model type="PAM.UninterruptiblePowerSupply" containment="true"
	 * @generated
	 */
	EList getApplies();

	/**
	 * Returns the value of the '<em><b>Contains</b></em>' containment reference list.
	 * The list contents are of type {@link PAM.Nodes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contains</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' containment reference list.
	 * @see PAM.PAMPackage#getRoom_Contains()
	 * @model type="PAM.Nodes" containment="true"
	 * @generated
	 */
	EList getContains();

	/**
	 * Returns the value of the '<em><b>Subrooms</b></em>' containment reference list.
	 * The list contents are of type {@link PAM.Room}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subrooms</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subrooms</em>' containment reference list.
	 * @see PAM.PAMPackage#getRoom_Subrooms()
	 * @model type="PAM.Room" containment="true"
	 * @generated
	 */
	EList getSubrooms();

	/**
	 * Returns the value of the '<em><b>Links</b></em>' containment reference list.
	 * The list contents are of type {@link PAM.NetworkObjectLink}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Links</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Links</em>' containment reference list.
	 * @see PAM.PAMPackage#getRoom_Links()
	 * @model type="PAM.NetworkObjectLink" containment="true"
	 * @generated
	 */
	EList getLinks();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PAM.PAMPackage#getRoom_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PAM.Room#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Room
