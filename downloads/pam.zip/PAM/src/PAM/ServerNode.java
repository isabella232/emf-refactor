/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Server Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.ServerNode#getMax_Capacity <em>Max Capacity</em>}</li>
 *   <li>{@link PAM.ServerNode#getIdle_Watt <em>Idle Watt</em>}</li>
 *   <li>{@link PAM.ServerNode#getAct_Watt <em>Act Watt</em>}</li>
 *   <li>{@link PAM.ServerNode#getMFLOPs <em>MFLO Ps</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getServerNode()
 * @model
 * @generated
 */
public interface ServerNode extends Nodes, Comparable {
	/**
	 * Returns the value of the '<em><b>Max Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Capacity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Capacity</em>' attribute.
	 * @see #setMax_Capacity(int)
	 * @see PAM.PAMPackage#getServerNode_Max_Capacity()
	 * @model
	 * @generated
	 */
	int getMax_Capacity();

	/**
	 * Sets the value of the '{@link PAM.ServerNode#getMax_Capacity <em>Max Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Capacity</em>' attribute.
	 * @see #getMax_Capacity()
	 * @generated
	 */
	void setMax_Capacity(int value);

	/**
	 * Returns the value of the '<em><b>Idle Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Idle Watt</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Idle Watt</em>' attribute.
	 * @see #setIdle_Watt(int)
	 * @see PAM.PAMPackage#getServerNode_Idle_Watt()
	 * @model
	 * @generated
	 */
	int getIdle_Watt();

	/**
	 * Sets the value of the '{@link PAM.ServerNode#getIdle_Watt <em>Idle Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Idle Watt</em>' attribute.
	 * @see #getIdle_Watt()
	 * @generated
	 */
	void setIdle_Watt(int value);

	/**
	 * Returns the value of the '<em><b>Act Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Act Watt</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Act Watt</em>' attribute.
	 * @see #setAct_Watt(int)
	 * @see PAM.PAMPackage#getServerNode_Act_Watt()
	 * @model
	 * @generated
	 */
	int getAct_Watt();

	/**
	 * Sets the value of the '{@link PAM.ServerNode#getAct_Watt <em>Act Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Act Watt</em>' attribute.
	 * @see #getAct_Watt()
	 * @generated
	 */
	void setAct_Watt(int value);

	/**
	 * Returns the value of the '<em><b>MFLO Ps</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>MFLO Ps</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>MFLO Ps</em>' attribute.
	 * @see #setMFLOPs(int)
	 * @see PAM.PAMPackage#getServerNode_MFLOPs()
	 * @model
	 * @generated
	 */
	int getMFLOPs();

	/**
	 * Sets the value of the '{@link PAM.ServerNode#getMFLOPs <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>MFLO Ps</em>' attribute.
	 * @see #getMFLOPs()
	 * @generated
	 */
	void setMFLOPs(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/GenModel body='\r\nServerNode server1 = (ServerNode) o;\r\n\r\nif ((getMax_Watt() < server1.getMax_Watt() && getAct_Watt() <= server1.getAct_Watt()) && getIdle_Watt() <= server1.getIdle_Watt() ||\r\n     (getMax_Watt() <= server1.getMax_Watt() && getAct_Watt() < server1.getAct_Watt()) && getIdle_Watt() <= server1.getIdle_Watt() ||\r\n     (getMax_Watt() <= server1.getMax_Watt() && getAct_Watt() <= server1.getAct_Watt()) && getIdle_Watt() < server1.getIdle_Watt()) {\r\n\treturn -1;\r\n}\r\n\r\nif ((getMax_Watt() == server1.getMax_Watt() && getAct_Watt() == server1.getAct_Watt()) && getIdle_Watt() == server1.getIdle_Watt()) {\r\n\treturn 0;\r\n}\r\n\r\nif ((server1.getMax_Watt() < getMax_Watt() && server1.getAct_Watt() <= getAct_Watt()) && server1.getIdle_Watt() <= getIdle_Watt() ||\r\n     (server1.getMax_Watt() <= getMax_Watt() && server1.getAct_Watt() < getAct_Watt()) && server1.getIdle_Watt() <= getIdle_Watt() ||\r\n     (server1.getMax_Watt() <= getMax_Watt() && server1.getAct_Watt() <= getAct_Watt()) && server1.getIdle_Watt() < getIdle_Watt()) {\r\n\treturn 1;\r\n}\r\n\t\t\r\nreturn 0;\r\n\t\t'"
	 * @generated
	 */
	int compareTo(Object o);

} // ServerNode
