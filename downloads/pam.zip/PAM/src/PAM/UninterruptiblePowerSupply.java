/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uninterruptible Power Supply</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PAM.UninterruptiblePowerSupply#getName <em>Name</em>}</li>
 *   <li>{@link PAM.UninterruptiblePowerSupply#getOut_Watt <em>Out Watt</em>}</li>
 *   <li>{@link PAM.UninterruptiblePowerSupply#getEfficiency <em>Efficiency</em>}</li>
 * </ul>
 * </p>
 *
 * @see PAM.PAMPackage#getUninterruptiblePowerSupply()
 * @model
 * @generated
 */
public interface UninterruptiblePowerSupply extends EObject , Comparable {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see PAM.PAMPackage#getUninterruptiblePowerSupply_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link PAM.UninterruptiblePowerSupply#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Out Watt</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Out Watt</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Out Watt</em>' attribute.
	 * @see #setOut_Watt(int)
	 * @see PAM.PAMPackage#getUninterruptiblePowerSupply_Out_Watt()
	 * @model
	 * @generated
	 */
	int getOut_Watt();

	/**
	 * Sets the value of the '{@link PAM.UninterruptiblePowerSupply#getOut_Watt <em>Out Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Out Watt</em>' attribute.
	 * @see #getOut_Watt()
	 * @generated
	 */
	void setOut_Watt(int value);

	/**
	 * Returns the value of the '<em><b>Efficiency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Efficiency</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Efficiency</em>' attribute.
	 * @see #setEfficiency(double)
	 * @see PAM.PAMPackage#getUninterruptiblePowerSupply_Efficiency()
	 * @model
	 * @generated
	 */
	double getEfficiency();

	/**
	 * Sets the value of the '{@link PAM.UninterruptiblePowerSupply#getEfficiency <em>Efficiency</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Efficiency</em>' attribute.
	 * @see #getEfficiency()
	 * @generated
	 */
	void setEfficiency(double value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/GenModel body='\t\t\r\nUninterruptiblePowerSupply ups1 = (UninterruptiblePowerSupply) o;\r\n\r\nif ((((getOut_Watt() / getEfficiency())*100)-getOut_Watt()) < (((ups1.getOut_Watt() / ups1.getEfficiency())*100)-ups1.getOut_Watt())) {\r\n\treturn -1;\r\n}\r\n\r\nif  ((((getOut_Watt() / getEfficiency())*100)-getOut_Watt()) == (((ups1.getOut_Watt() / ups1.getEfficiency())*100)-ups1.getOut_Watt())) {\r\n\treturn 0;\r\n}\r\n\r\nif (ups1.compareTo(this) == -1) {\r\n\treturn 1;\r\n}\r\n\r\nreturn 0;\r\n\t'"
	 * @generated
	 */
	int compareTo(Object o);

} // UninterruptiblePowerSupply
