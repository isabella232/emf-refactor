/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.ClientNode;
import PAM.PAMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Client Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.ClientNodeImpl#getMFLOPs <em>MFLO Ps</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ClientNodeImpl extends NodesImpl implements ClientNode {
	/**
	 * The default value of the '{@link #getMFLOPs() <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMFLOPs()
	 * @generated
	 * @ordered
	 */
	protected static final int MFLO_PS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMFLOPs() <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMFLOPs()
	 * @generated
	 * @ordered
	 */
	protected int mfloPs = MFLO_PS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClientNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.CLIENT_NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMFLOPs() {
		return mfloPs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMFLOPs(int newMFLOPs) {
		int oldMFLOPs = mfloPs;
		mfloPs = newMFLOPs;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.CLIENT_NODE__MFLO_PS, oldMFLOPs, mfloPs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	
	public int compareTo(Object o) {
		
		ClientNode client1 = (ClientNode) o;
				
		if (getMax_Watt() < client1.getMax_Watt()) {
			return -1;
		}
		
		if (getMax_Watt() == client1.getMax_Watt()) {
			return 0;
		}
		
		if (client1.compareTo(this) == -1) {
			return 1;
		}
		
		return 0;
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.CLIENT_NODE__MFLO_PS:
				return new Integer(getMFLOPs());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.CLIENT_NODE__MFLO_PS:
				setMFLOPs(((Integer)newValue).intValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.CLIENT_NODE__MFLO_PS:
				setMFLOPs(MFLO_PS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.CLIENT_NODE__MFLO_PS:
				return mfloPs != MFLO_PS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (MFLOPs: ");
		result.append(mfloPs);
		result.append(')');
		return result.toString();
	}

} //ClientNodeImpl
