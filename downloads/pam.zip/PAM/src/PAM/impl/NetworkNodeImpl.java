/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.NetworkNode;
import PAM.PAMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Network Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.NetworkNodeImpl#getMax_Throughput <em>Max Throughput</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NetworkNodeImpl extends NodesImpl implements NetworkNode {
	/**
	 * The default value of the '{@link #getMax_Throughput() <em>Max Throughput</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMax_Throughput()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_THROUGHPUT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMax_Throughput() <em>Max Throughput</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMax_Throughput()
	 * @generated
	 * @ordered
	 */
	protected int max_Throughput = MAX_THROUGHPUT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.NETWORK_NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMax_Throughput() {
		return max_Throughput;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMax_Throughput(int newMax_Throughput) {
		int oldMax_Throughput = max_Throughput;
		max_Throughput = newMax_Throughput;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.NETWORK_NODE__MAX_THROUGHPUT, oldMax_Throughput, max_Throughput));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int compareTo(Object o) {
		
		NetworkNode Network1 = (NetworkNode) o;
		
		if ((getMax_Watt() < Network1.getMax_Watt()) || (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() < Network1.getMax_Throughput())) {
			return -1;
		}
		
		if (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() == Network1.getMax_Throughput()) {
			return 0;
		}
		
		if ((getMax_Watt() > Network1.getMax_Watt()) || (getMax_Watt() == Network1.getMax_Watt() && getMax_Throughput() > Network1.getMax_Throughput())) {
			return 1;
		}
				
		return 0;
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.NETWORK_NODE__MAX_THROUGHPUT:
				return new Integer(getMax_Throughput());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.NETWORK_NODE__MAX_THROUGHPUT:
				setMax_Throughput(((Integer)newValue).intValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.NETWORK_NODE__MAX_THROUGHPUT:
				setMax_Throughput(MAX_THROUGHPUT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.NETWORK_NODE__MAX_THROUGHPUT:
				return max_Throughput != MAX_THROUGHPUT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Max_Throughput: ");
		result.append(max_Throughput);
		result.append(')');
		return result.toString();
	}

} //NetworkNodeImpl
