/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.NetworkNode;
import PAM.NetworkObjectLink;
import PAM.Nodes;
import PAM.PAMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Network Object Link</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.NetworkObjectLinkImpl#getConnect0 <em>Connect0</em>}</li>
 *   <li>{@link PAM.impl.NetworkObjectLinkImpl#getConnect1 <em>Connect1</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class NetworkObjectLinkImpl extends EObjectImpl implements NetworkObjectLink {
	/**
	 * The cached value of the '{@link #getConnect0() <em>Connect0</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnect0()
	 * @generated
	 * @ordered
	 */
	protected Nodes connect0;

	/**
	 * The cached value of the '{@link #getConnect1() <em>Connect1</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnect1()
	 * @generated
	 * @ordered
	 */
	protected NetworkNode connect1;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NetworkObjectLinkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.NETWORK_OBJECT_LINK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Nodes getConnect0() {
		if (connect0 != null && connect0.eIsProxy()) {
			InternalEObject oldConnect0 = (InternalEObject)connect0;
			connect0 = (Nodes)eResolveProxy(oldConnect0);
			if (connect0 != oldConnect0) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PAMPackage.NETWORK_OBJECT_LINK__CONNECT0, oldConnect0, connect0));
			}
		}
		return connect0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Nodes basicGetConnect0() {
		return connect0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnect0(Nodes newConnect0) {
		Nodes oldConnect0 = connect0;
		connect0 = newConnect0;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.NETWORK_OBJECT_LINK__CONNECT0, oldConnect0, connect0));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkNode getConnect1() {
		if (connect1 != null && connect1.eIsProxy()) {
			InternalEObject oldConnect1 = (InternalEObject)connect1;
			connect1 = (NetworkNode)eResolveProxy(oldConnect1);
			if (connect1 != oldConnect1) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PAMPackage.NETWORK_OBJECT_LINK__CONNECT1, oldConnect1, connect1));
			}
		}
		return connect1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkNode basicGetConnect1() {
		return connect1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnect1(NetworkNode newConnect1) {
		NetworkNode oldConnect1 = connect1;
		connect1 = newConnect1;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.NETWORK_OBJECT_LINK__CONNECT1, oldConnect1, connect1));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT0:
				if (resolve) return getConnect0();
				return basicGetConnect0();
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT1:
				if (resolve) return getConnect1();
				return basicGetConnect1();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT0:
				setConnect0((Nodes)newValue);
				return;
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT1:
				setConnect1((NetworkNode)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT0:
				setConnect0((Nodes)null);
				return;
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT1:
				setConnect1((NetworkNode)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT0:
				return connect0 != null;
			case PAMPackage.NETWORK_OBJECT_LINK__CONNECT1:
				return connect1 != null;
		}
		return super.eIsSet(featureID);
	}

} //NetworkObjectLinkImpl
