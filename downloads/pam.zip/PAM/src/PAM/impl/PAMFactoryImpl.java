/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PAMFactoryImpl extends EFactoryImpl implements PAMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PAMFactory init() {
		try {
			PAMFactory thePAMFactory = (PAMFactory)EPackage.Registry.INSTANCE.getEFactory("PAM"); 
			if (thePAMFactory != null) {
				return thePAMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PAMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PAMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case PAMPackage.NETWORK_NODE: return createNetworkNode();
			case PAMPackage.SERVER_NODE: return createServerNode();
			case PAMPackage.CLIENT_NODE: return createClientNode();
			case PAMPackage.NETWORK_OBJECT_LINK: return createNetworkObjectLink();
			case PAMPackage.ROOM: return createRoom();
			case PAMPackage.COOLING: return createCooling();
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY: return createUninterruptiblePowerSupply();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkNode createNetworkNode() {
		NetworkNodeImpl networkNode = new NetworkNodeImpl();
		return networkNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServerNode createServerNode() {
		ServerNodeImpl serverNode = new ServerNodeImpl();
		return serverNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClientNode createClientNode() {
		ClientNodeImpl clientNode = new ClientNodeImpl();
		return clientNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkObjectLink createNetworkObjectLink() {
		NetworkObjectLinkImpl networkObjectLink = new NetworkObjectLinkImpl();
		return networkObjectLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Room createRoom() {
		RoomImpl room = new RoomImpl();
		return room;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cooling createCooling() {
		CoolingImpl cooling = new CoolingImpl();
		return cooling;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UninterruptiblePowerSupply createUninterruptiblePowerSupply() {
		UninterruptiblePowerSupplyImpl uninterruptiblePowerSupply = new UninterruptiblePowerSupplyImpl();
		return uninterruptiblePowerSupply;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PAMPackage getPAMPackage() {
		return (PAMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static PAMPackage getPackage() {
		return PAMPackage.eINSTANCE;
	}

} //PAMFactoryImpl
