/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.ClientNode;
import PAM.Cooling;
import PAM.NetworkNode;
import PAM.NetworkObjectLink;
import PAM.Nodes;
import PAM.PAMFactory;
import PAM.PAMPackage;
import PAM.Room;
import PAM.ServerNode;
import PAM.UninterruptiblePowerSupply;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PAMPackageImpl extends EPackageImpl implements PAMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nodesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass networkNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serverNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clientNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass networkObjectLinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roomEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass coolingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass uninterruptiblePowerSupplyEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see PAM.PAMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PAMPackageImpl() {
		super(eNS_URI, PAMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link PAMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PAMPackage init() {
		if (isInited) return (PAMPackage)EPackage.Registry.INSTANCE.getEPackage(PAMPackage.eNS_URI);

		// Obtain or create and register package
		PAMPackageImpl thePAMPackage = (PAMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof PAMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new PAMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		thePAMPackage.createPackageContents();

		// Initialize created meta-data
		thePAMPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		thePAMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(PAMPackage.eNS_URI, thePAMPackage);
		return thePAMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNodes() {
		return nodesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodes_Name() {
		return (EAttribute)nodesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNodes_Max_Watt() {
		return (EAttribute)nodesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetworkNode() {
		return networkNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNetworkNode_Max_Throughput() {
		return (EAttribute)networkNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServerNode() {
		return serverNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServerNode_Max_Capacity() {
		return (EAttribute)serverNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServerNode_Idle_Watt() {
		return (EAttribute)serverNodeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServerNode_Act_Watt() {
		return (EAttribute)serverNodeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServerNode_MFLOPs() {
		return (EAttribute)serverNodeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClientNode() {
		return clientNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClientNode_MFLOPs() {
		return (EAttribute)clientNodeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetworkObjectLink() {
		return networkObjectLinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNetworkObjectLink_Connect0() {
		return (EReference)networkObjectLinkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getNetworkObjectLink_Connect1() {
		return (EReference)networkObjectLinkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRoom() {
		return roomEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoom_Includes() {
		return (EReference)roomEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoom_Applies() {
		return (EReference)roomEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoom_Contains() {
		return (EReference)roomEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoom_Subrooms() {
		return (EReference)roomEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRoom_Links() {
		return (EReference)roomEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRoom_Name() {
		return (EAttribute)roomEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCooling() {
		return coolingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCooling_Max_Watt() {
		return (EAttribute)coolingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCooling_Name() {
		return (EAttribute)coolingEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCooling_Cooling_Capacity() {
		return (EAttribute)coolingEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUninterruptiblePowerSupply() {
		return uninterruptiblePowerSupplyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUninterruptiblePowerSupply_Name() {
		return (EAttribute)uninterruptiblePowerSupplyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUninterruptiblePowerSupply_Out_Watt() {
		return (EAttribute)uninterruptiblePowerSupplyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUninterruptiblePowerSupply_Efficiency() {
		return (EAttribute)uninterruptiblePowerSupplyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PAMFactory getPAMFactory() {
		return (PAMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		nodesEClass = createEClass(NODES);
		createEAttribute(nodesEClass, NODES__NAME);
		createEAttribute(nodesEClass, NODES__MAX_WATT);

		networkNodeEClass = createEClass(NETWORK_NODE);
		createEAttribute(networkNodeEClass, NETWORK_NODE__MAX_THROUGHPUT);

		serverNodeEClass = createEClass(SERVER_NODE);
		createEAttribute(serverNodeEClass, SERVER_NODE__MAX_CAPACITY);
		createEAttribute(serverNodeEClass, SERVER_NODE__IDLE_WATT);
		createEAttribute(serverNodeEClass, SERVER_NODE__ACT_WATT);
		createEAttribute(serverNodeEClass, SERVER_NODE__MFLO_PS);

		clientNodeEClass = createEClass(CLIENT_NODE);
		createEAttribute(clientNodeEClass, CLIENT_NODE__MFLO_PS);

		networkObjectLinkEClass = createEClass(NETWORK_OBJECT_LINK);
		createEReference(networkObjectLinkEClass, NETWORK_OBJECT_LINK__CONNECT0);
		createEReference(networkObjectLinkEClass, NETWORK_OBJECT_LINK__CONNECT1);

		roomEClass = createEClass(ROOM);
		createEReference(roomEClass, ROOM__INCLUDES);
		createEReference(roomEClass, ROOM__APPLIES);
		createEReference(roomEClass, ROOM__CONTAINS);
		createEReference(roomEClass, ROOM__SUBROOMS);
		createEReference(roomEClass, ROOM__LINKS);
		createEAttribute(roomEClass, ROOM__NAME);

		coolingEClass = createEClass(COOLING);
		createEAttribute(coolingEClass, COOLING__MAX_WATT);
		createEAttribute(coolingEClass, COOLING__NAME);
		createEAttribute(coolingEClass, COOLING__COOLING_CAPACITY);

		uninterruptiblePowerSupplyEClass = createEClass(UNINTERRUPTIBLE_POWER_SUPPLY);
		createEAttribute(uninterruptiblePowerSupplyEClass, UNINTERRUPTIBLE_POWER_SUPPLY__NAME);
		createEAttribute(uninterruptiblePowerSupplyEClass, UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT);
		createEAttribute(uninterruptiblePowerSupplyEClass, UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Add supertypes to classes
		networkNodeEClass.getESuperTypes().add(this.getNodes());
		serverNodeEClass.getESuperTypes().add(this.getNodes());
		clientNodeEClass.getESuperTypes().add(this.getNodes());

		// Initialize classes and features; add operations and parameters
		initEClass(nodesEClass, Nodes.class, "Nodes", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNodes_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Nodes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNodes_Max_Watt(), ecorePackage.getEInt(), "Max_Watt", null, 0, 1, Nodes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(networkNodeEClass, NetworkNode.class, "NetworkNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNetworkNode_Max_Throughput(), ecorePackage.getEInt(), "Max_Throughput", null, 0, 1, NetworkNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = addEOperation(networkNodeEClass, ecorePackage.getEInt(), "compareTo", 0, 1);
		addEParameter(op, ecorePackage.getEJavaObject(), "o", 0, 1);

		initEClass(serverNodeEClass, ServerNode.class, "ServerNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getServerNode_Max_Capacity(), ecorePackage.getEInt(), "Max_Capacity", null, 0, 1, ServerNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServerNode_Idle_Watt(), ecorePackage.getEInt(), "Idle_Watt", null, 0, 1, ServerNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServerNode_Act_Watt(), ecorePackage.getEInt(), "Act_Watt", null, 0, 1, ServerNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServerNode_MFLOPs(), ecorePackage.getEInt(), "MFLOPs", null, 0, 1, ServerNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = addEOperation(serverNodeEClass, ecorePackage.getEInt(), "compareTo", 0, 1);
		addEParameter(op, ecorePackage.getEJavaObject(), "o", 0, 1);

		initEClass(clientNodeEClass, ClientNode.class, "ClientNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getClientNode_MFLOPs(), ecorePackage.getEInt(), "MFLOPs", null, 0, 1, ClientNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = addEOperation(clientNodeEClass, ecorePackage.getEInt(), "compareTo", 0, 1);
		addEParameter(op, ecorePackage.getEJavaObject(), "o", 0, 1);

		initEClass(networkObjectLinkEClass, NetworkObjectLink.class, "NetworkObjectLink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getNetworkObjectLink_Connect0(), this.getNodes(), null, "connect0", null, 1, 1, NetworkObjectLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getNetworkObjectLink_Connect1(), this.getNetworkNode(), null, "connect1", null, 1, 1, NetworkObjectLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(roomEClass, Room.class, "Room", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRoom_Includes(), this.getCooling(), null, "includes", null, 0, -1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoom_Applies(), this.getUninterruptiblePowerSupply(), null, "applies", null, 0, -1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoom_Contains(), this.getNodes(), null, "contains", null, 0, -1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoom_Subrooms(), this.getRoom(), null, "subrooms", null, 0, -1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRoom_Links(), this.getNetworkObjectLink(), null, "links", null, 0, -1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRoom_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Room.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(coolingEClass, Cooling.class, "Cooling", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCooling_Max_Watt(), ecorePackage.getEInt(), "Max_Watt", "0", 0, 1, Cooling.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCooling_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Cooling.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCooling_Cooling_Capacity(), ecorePackage.getEInt(), "Cooling_Capacity", "0", 0, 1, Cooling.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = addEOperation(coolingEClass, ecorePackage.getEInt(), "compareTo", 0, 1);
		addEParameter(op, ecorePackage.getEJavaObject(), "o", 0, 1);

		initEClass(uninterruptiblePowerSupplyEClass, UninterruptiblePowerSupply.class, "UninterruptiblePowerSupply", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUninterruptiblePowerSupply_Name(), ecorePackage.getEString(), "Name", null, 0, 1, UninterruptiblePowerSupply.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getUninterruptiblePowerSupply_Out_Watt(), ecorePackage.getEInt(), "Out_Watt", null, 0, 1, UninterruptiblePowerSupply.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getUninterruptiblePowerSupply_Efficiency(), ecorePackage.getEDouble(), "Efficiency", null, 0, 1, UninterruptiblePowerSupply.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = addEOperation(uninterruptiblePowerSupplyEClass, ecorePackage.getEInt(), "compareTo", 0, 1);
		addEParameter(op, ecorePackage.getEJavaObject(), "o", 0, 1);

		// Create resource
		createResource(eNS_URI);
	}

} //PAMPackageImpl
