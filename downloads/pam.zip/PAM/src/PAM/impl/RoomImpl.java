/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.Cooling;
import PAM.NetworkObjectLink;
import PAM.Nodes;
import PAM.PAMPackage;
import PAM.Room;
import PAM.UninterruptiblePowerSupply;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.RoomImpl#getIncludes <em>Includes</em>}</li>
 *   <li>{@link PAM.impl.RoomImpl#getApplies <em>Applies</em>}</li>
 *   <li>{@link PAM.impl.RoomImpl#getContains <em>Contains</em>}</li>
 *   <li>{@link PAM.impl.RoomImpl#getSubrooms <em>Subrooms</em>}</li>
 *   <li>{@link PAM.impl.RoomImpl#getLinks <em>Links</em>}</li>
 *   <li>{@link PAM.impl.RoomImpl#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RoomImpl extends EObjectImpl implements Room {
	/**
	 * The cached value of the '{@link #getIncludes() <em>Includes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludes()
	 * @generated
	 * @ordered
	 */
	protected EList includes;

	/**
	 * The cached value of the '{@link #getApplies() <em>Applies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getApplies()
	 * @generated
	 * @ordered
	 */
	protected EList applies;

	/**
	 * The cached value of the '{@link #getContains() <em>Contains</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContains()
	 * @generated
	 * @ordered
	 */
	protected EList contains;

	/**
	 * The cached value of the '{@link #getSubrooms() <em>Subrooms</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubrooms()
	 * @generated
	 * @ordered
	 */
	protected EList subrooms;

	/**
	 * The cached value of the '{@link #getLinks() <em>Links</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinks()
	 * @generated
	 * @ordered
	 */
	protected EList links;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoomImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.ROOM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getIncludes() {
		if (includes == null) {
			includes = new EObjectContainmentEList(Cooling.class, this, PAMPackage.ROOM__INCLUDES);
		}
		return includes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getApplies() {
		if (applies == null) {
			applies = new EObjectContainmentEList(UninterruptiblePowerSupply.class, this, PAMPackage.ROOM__APPLIES);
		}
		return applies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getContains() {
		if (contains == null) {
			contains = new EObjectContainmentEList(Nodes.class, this, PAMPackage.ROOM__CONTAINS);
		}
		return contains;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getSubrooms() {
		if (subrooms == null) {
			subrooms = new EObjectContainmentEList(Room.class, this, PAMPackage.ROOM__SUBROOMS);
		}
		return subrooms;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getLinks() {
		if (links == null) {
			links = new EObjectContainmentEList(NetworkObjectLink.class, this, PAMPackage.ROOM__LINKS);
		}
		return links;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.ROOM__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PAMPackage.ROOM__INCLUDES:
				return ((InternalEList)getIncludes()).basicRemove(otherEnd, msgs);
			case PAMPackage.ROOM__APPLIES:
				return ((InternalEList)getApplies()).basicRemove(otherEnd, msgs);
			case PAMPackage.ROOM__CONTAINS:
				return ((InternalEList)getContains()).basicRemove(otherEnd, msgs);
			case PAMPackage.ROOM__SUBROOMS:
				return ((InternalEList)getSubrooms()).basicRemove(otherEnd, msgs);
			case PAMPackage.ROOM__LINKS:
				return ((InternalEList)getLinks()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.ROOM__INCLUDES:
				return getIncludes();
			case PAMPackage.ROOM__APPLIES:
				return getApplies();
			case PAMPackage.ROOM__CONTAINS:
				return getContains();
			case PAMPackage.ROOM__SUBROOMS:
				return getSubrooms();
			case PAMPackage.ROOM__LINKS:
				return getLinks();
			case PAMPackage.ROOM__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.ROOM__INCLUDES:
				getIncludes().clear();
				getIncludes().addAll((Collection)newValue);
				return;
			case PAMPackage.ROOM__APPLIES:
				getApplies().clear();
				getApplies().addAll((Collection)newValue);
				return;
			case PAMPackage.ROOM__CONTAINS:
				getContains().clear();
				getContains().addAll((Collection)newValue);
				return;
			case PAMPackage.ROOM__SUBROOMS:
				getSubrooms().clear();
				getSubrooms().addAll((Collection)newValue);
				return;
			case PAMPackage.ROOM__LINKS:
				getLinks().clear();
				getLinks().addAll((Collection)newValue);
				return;
			case PAMPackage.ROOM__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.ROOM__INCLUDES:
				getIncludes().clear();
				return;
			case PAMPackage.ROOM__APPLIES:
				getApplies().clear();
				return;
			case PAMPackage.ROOM__CONTAINS:
				getContains().clear();
				return;
			case PAMPackage.ROOM__SUBROOMS:
				getSubrooms().clear();
				return;
			case PAMPackage.ROOM__LINKS:
				getLinks().clear();
				return;
			case PAMPackage.ROOM__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.ROOM__INCLUDES:
				return includes != null && !includes.isEmpty();
			case PAMPackage.ROOM__APPLIES:
				return applies != null && !applies.isEmpty();
			case PAMPackage.ROOM__CONTAINS:
				return contains != null && !contains.isEmpty();
			case PAMPackage.ROOM__SUBROOMS:
				return subrooms != null && !subrooms.isEmpty();
			case PAMPackage.ROOM__LINKS:
				return links != null && !links.isEmpty();
			case PAMPackage.ROOM__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //RoomImpl
