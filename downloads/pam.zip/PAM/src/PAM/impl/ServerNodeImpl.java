/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.PAMPackage;
import PAM.ServerNode;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Server Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.ServerNodeImpl#getMax_Capacity <em>Max Capacity</em>}</li>
 *   <li>{@link PAM.impl.ServerNodeImpl#getIdle_Watt <em>Idle Watt</em>}</li>
 *   <li>{@link PAM.impl.ServerNodeImpl#getAct_Watt <em>Act Watt</em>}</li>
 *   <li>{@link PAM.impl.ServerNodeImpl#getMFLOPs <em>MFLO Ps</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ServerNodeImpl extends NodesImpl implements ServerNode {
	/**
	 * The default value of the '{@link #getMax_Capacity() <em>Max Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMax_Capacity()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_CAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMax_Capacity() <em>Max Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMax_Capacity()
	 * @generated
	 * @ordered
	 */
	protected int max_Capacity = MAX_CAPACITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getIdle_Watt() <em>Idle Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdle_Watt()
	 * @generated
	 * @ordered
	 */
	protected static final int IDLE_WATT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getIdle_Watt() <em>Idle Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdle_Watt()
	 * @generated
	 * @ordered
	 */
	protected int idle_Watt = IDLE_WATT_EDEFAULT;

	/**
	 * The default value of the '{@link #getAct_Watt() <em>Act Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAct_Watt()
	 * @generated
	 * @ordered
	 */
	protected static final int ACT_WATT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAct_Watt() <em>Act Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAct_Watt()
	 * @generated
	 * @ordered
	 */
	protected int act_Watt = ACT_WATT_EDEFAULT;

	/**
	 * The default value of the '{@link #getMFLOPs() <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMFLOPs()
	 * @generated
	 * @ordered
	 */
	protected static final int MFLO_PS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMFLOPs() <em>MFLO Ps</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMFLOPs()
	 * @generated
	 * @ordered
	 */
	protected int mfloPs = MFLO_PS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServerNodeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.SERVER_NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMax_Capacity() {
		return max_Capacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMax_Capacity(int newMax_Capacity) {
		int oldMax_Capacity = max_Capacity;
		max_Capacity = newMax_Capacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.SERVER_NODE__MAX_CAPACITY, oldMax_Capacity, max_Capacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getIdle_Watt() {
		return idle_Watt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIdle_Watt(int newIdle_Watt) {
		int oldIdle_Watt = idle_Watt;
		idle_Watt = newIdle_Watt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.SERVER_NODE__IDLE_WATT, oldIdle_Watt, idle_Watt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getAct_Watt() {
		return act_Watt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAct_Watt(int newAct_Watt) {
		int oldAct_Watt = act_Watt;
		act_Watt = newAct_Watt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.SERVER_NODE__ACT_WATT, oldAct_Watt, act_Watt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMFLOPs() {
		return mfloPs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMFLOPs(int newMFLOPs) {
		int oldMFLOPs = mfloPs;
		mfloPs = newMFLOPs;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.SERVER_NODE__MFLO_PS, oldMFLOPs, mfloPs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int compareTo(Object o) {
		
		ServerNode server1 = (ServerNode) o;
		
		if ((getMax_Watt() < server1.getMax_Watt() && getAct_Watt() <= server1.getAct_Watt()) && getIdle_Watt() <= server1.getIdle_Watt() ||
		     (getMax_Watt() <= server1.getMax_Watt() && getAct_Watt() < server1.getAct_Watt()) && getIdle_Watt() <= server1.getIdle_Watt() ||
		     (getMax_Watt() <= server1.getMax_Watt() && getAct_Watt() <= server1.getAct_Watt()) && getIdle_Watt() < server1.getIdle_Watt()) {
			return -1;
		}
		
		if ((getMax_Watt() == server1.getMax_Watt() && getAct_Watt() == server1.getAct_Watt()) && getIdle_Watt() == server1.getIdle_Watt()) {
			return 0;
		}
		
		if ((server1.getMax_Watt() < getMax_Watt() && server1.getAct_Watt() <= getAct_Watt()) && server1.getIdle_Watt() <= getIdle_Watt() ||
		     (server1.getMax_Watt() <= getMax_Watt() && server1.getAct_Watt() < getAct_Watt()) && server1.getIdle_Watt() <= getIdle_Watt() ||
		     (server1.getMax_Watt() <= getMax_Watt() && server1.getAct_Watt() <= getAct_Watt()) && server1.getIdle_Watt() < getIdle_Watt()) {
			return 1;
		}
				
		return 0;
				
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.SERVER_NODE__MAX_CAPACITY:
				return new Integer(getMax_Capacity());
			case PAMPackage.SERVER_NODE__IDLE_WATT:
				return new Integer(getIdle_Watt());
			case PAMPackage.SERVER_NODE__ACT_WATT:
				return new Integer(getAct_Watt());
			case PAMPackage.SERVER_NODE__MFLO_PS:
				return new Integer(getMFLOPs());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.SERVER_NODE__MAX_CAPACITY:
				setMax_Capacity(((Integer)newValue).intValue());
				return;
			case PAMPackage.SERVER_NODE__IDLE_WATT:
				setIdle_Watt(((Integer)newValue).intValue());
				return;
			case PAMPackage.SERVER_NODE__ACT_WATT:
				setAct_Watt(((Integer)newValue).intValue());
				return;
			case PAMPackage.SERVER_NODE__MFLO_PS:
				setMFLOPs(((Integer)newValue).intValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.SERVER_NODE__MAX_CAPACITY:
				setMax_Capacity(MAX_CAPACITY_EDEFAULT);
				return;
			case PAMPackage.SERVER_NODE__IDLE_WATT:
				setIdle_Watt(IDLE_WATT_EDEFAULT);
				return;
			case PAMPackage.SERVER_NODE__ACT_WATT:
				setAct_Watt(ACT_WATT_EDEFAULT);
				return;
			case PAMPackage.SERVER_NODE__MFLO_PS:
				setMFLOPs(MFLO_PS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.SERVER_NODE__MAX_CAPACITY:
				return max_Capacity != MAX_CAPACITY_EDEFAULT;
			case PAMPackage.SERVER_NODE__IDLE_WATT:
				return idle_Watt != IDLE_WATT_EDEFAULT;
			case PAMPackage.SERVER_NODE__ACT_WATT:
				return act_Watt != ACT_WATT_EDEFAULT;
			case PAMPackage.SERVER_NODE__MFLO_PS:
				return mfloPs != MFLO_PS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Max_Capacity: ");
		result.append(max_Capacity);
		result.append(", Idle_Watt: ");
		result.append(idle_Watt);
		result.append(", Act_Watt: ");
		result.append(act_Watt);
		result.append(", MFLOPs: ");
		result.append(mfloPs);
		result.append(')');
		return result.toString();
	}

} //ServerNodeImpl
