/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package PAM.impl;

import PAM.PAMPackage;
import PAM.UninterruptiblePowerSupply;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uninterruptible Power Supply</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link PAM.impl.UninterruptiblePowerSupplyImpl#getName <em>Name</em>}</li>
 *   <li>{@link PAM.impl.UninterruptiblePowerSupplyImpl#getOut_Watt <em>Out Watt</em>}</li>
 *   <li>{@link PAM.impl.UninterruptiblePowerSupplyImpl#getEfficiency <em>Efficiency</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class UninterruptiblePowerSupplyImpl extends EObjectImpl implements UninterruptiblePowerSupply {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getOut_Watt() <em>Out Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOut_Watt()
	 * @generated
	 * @ordered
	 */
	protected static final int OUT_WATT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getOut_Watt() <em>Out Watt</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOut_Watt()
	 * @generated
	 * @ordered
	 */
	protected int out_Watt = OUT_WATT_EDEFAULT;

	/**
	 * The default value of the '{@link #getEfficiency() <em>Efficiency</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEfficiency()
	 * @generated
	 * @ordered
	 */
	protected static final double EFFICIENCY_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getEfficiency() <em>Efficiency</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEfficiency()
	 * @generated
	 * @ordered
	 */
	protected double efficiency = EFFICIENCY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UninterruptiblePowerSupplyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PAMPackage.Literals.UNINTERRUPTIBLE_POWER_SUPPLY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getOut_Watt() {
		return out_Watt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOut_Watt(int newOut_Watt) {
		int oldOut_Watt = out_Watt;
		out_Watt = newOut_Watt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT, oldOut_Watt, out_Watt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getEfficiency() {
		return efficiency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEfficiency(double newEfficiency) {
		double oldEfficiency = efficiency;
		efficiency = newEfficiency;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY, oldEfficiency, efficiency));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int compareTo(Object o) {
				
		UninterruptiblePowerSupply ups1 = (UninterruptiblePowerSupply) o;
		
		if ((((getOut_Watt() / getEfficiency())*100)-getOut_Watt()) < (((ups1.getOut_Watt() / ups1.getEfficiency())*100)-ups1.getOut_Watt())) {
			return -1;
		}
		
		if  ((((getOut_Watt() / getEfficiency())*100)-getOut_Watt()) == (((ups1.getOut_Watt() / ups1.getEfficiency())*100)-ups1.getOut_Watt())) {
			return 0;
		}
		
		if (ups1.compareTo(this) == -1) {
			return 1;
		}
		
		return 0;
			
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__NAME:
				return getName();
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT:
				return new Integer(getOut_Watt());
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY:
				return new Double(getEfficiency());
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__NAME:
				setName((String)newValue);
				return;
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT:
				setOut_Watt(((Integer)newValue).intValue());
				return;
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY:
				setEfficiency(((Double)newValue).doubleValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__NAME:
				setName(NAME_EDEFAULT);
				return;
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT:
				setOut_Watt(OUT_WATT_EDEFAULT);
				return;
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY:
				setEfficiency(EFFICIENCY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__OUT_WATT:
				return out_Watt != OUT_WATT_EDEFAULT;
			case PAMPackage.UNINTERRUPTIBLE_POWER_SUPPLY__EFFICIENCY:
				return efficiency != EFFICIENCY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Out_Watt: ");
		result.append(out_Watt);
		result.append(", Efficiency: ");
		result.append(efficiency);
		result.append(')');
		return result.toString();
	}

} //UninterruptiblePowerSupplyImpl
