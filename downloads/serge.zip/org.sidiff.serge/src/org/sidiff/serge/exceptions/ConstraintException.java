package org.sidiff.serge.exceptions;

@SuppressWarnings("serial")
public class ConstraintException extends Exception{

	public ConstraintException(String s) {
		super(s);
	}
}
