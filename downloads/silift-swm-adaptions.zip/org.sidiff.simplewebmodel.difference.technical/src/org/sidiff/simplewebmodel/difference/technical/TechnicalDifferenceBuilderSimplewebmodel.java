package org.sidiff.simplewebmodel.difference.technical;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.resource.Resource;
import org.sidiff.difference.technical.TechnicalDifferenceBuilder;
import org.sidiff.difference.util.access.EMFModelAccessEx;

import simplewebmodel.SimplewebmodelPackage;

public class TechnicalDifferenceBuilderSimplewebmodel extends TechnicalDifferenceBuilder {
	
	@Override
	protected Set<EClass> getUnconsideredNodeTypes() {
		Set<EClass> unconsideredNodeTypes = new HashSet<EClass>();
		
		// nothing to filter here
		
		return unconsideredNodeTypes;
	}

	@Override
	protected Set<EReference> getUnconsideredEdgeTypes() {
		Set<EReference> unconsideredEdgeTypes = new HashSet<EReference>();
		
		// nothing to filter here
		
		return unconsideredEdgeTypes;
	}

	@Override
	protected Set<EAttribute> getUnconsideredAttributeTypes() {
		Set<EAttribute> unconsideredAttributeTypes = new HashSet<EAttribute>();
		
		// nothing to filter here
		
		return unconsideredAttributeTypes;
	}

	@Override
	protected void checkDocumentType(Resource model) {
		String docType = EMFModelAccessEx.getCharacteristicDocumentType(model);
		assert (docType.equals(SimplewebmodelPackage.eNS_URI)) : "Wrong document type: Expected " + SimplewebmodelPackage.eNS_URI + " but got " + docType;
	}
	
	@Override
	protected String getObjectName(EObject obj) {
		for (EAttribute attr : obj.eClass().getEAllAttributes()) {
			if(attr.getName().equals("name")){
				return (String) obj.eGet(attr);
			}
		}
		
		return "anonymous(" + obj.eClass().getName() + ")";
	}

	@Override
	public String getDocumentType() {
		return SimplewebmodelPackage.eNS_URI;
	}
}
