package org.sidiff.simplewebmodel.matcher;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.sidiff.difference.matcher.BaseMatcher;
import org.sidiff.difference.util.access.EMFModelAccessEx;

import simplewebmodel.DataLayer;
import simplewebmodel.HypertextLayer;
import simplewebmodel.Link;
import simplewebmodel.Page;
import simplewebmodel.SimplewebmodelPackage;
import simplewebmodel.WebModel;

/**
 * Basically NamedElement Matcher, special handling of Links, DataLayer and
 * HypertextLayer.
 * 
 * @author kehrer
 */
public class SimplewebmodelMatcher extends BaseMatcher {

	public static final String KEY = "Simplewebmodel";

	/**
	 * Initialize matcher and start matching.
	 */
	public SimplewebmodelMatcher() {
		super();
	}

	@Override
	protected boolean isCorresponding(EObject elementA, EObject elementB) {
		assert (elementA != null && elementB != null) : "One of the elements to check for correspondence is null!";

		// type should be identical in order to correspond
		if (elementA.eClass() != elementB.eClass()) {
			return false;
		}

		// None of the elements must be already in a correspondence
		if (isCorresponding(elementA) || isCorresponding(elementB)) {
			return false;
		}

		// "Singleton" elements
		if (elementA instanceof HypertextLayer || elementA instanceof DataLayer || elementA instanceof WebModel) {
			return true;
		}
		
		// Links
		if (elementA instanceof Link){
			Page srcA = ((Link) elementA).getSource();
			Page tgtA = ((Link) elementA).getTarget();		
			
			Page srcB = ((Link) elementB).getSource();
			Page tgtB = ((Link) elementB).getTarget();
			
			return equalNames(srcA, srcB) && equalNames(tgtA, tgtB);
		}
		
		// Named Elements
		return equalNames(elementA, elementB);
	}

	private boolean equalNames(EObject elementA, EObject elementB) {
		if (elementA == null || elementB == null){
			return false;
		}
		
		// Check for attribute "name" and its values equality
		EStructuralFeature attrName = elementA.eClass().getEStructuralFeature("name");
		if (attrName != null && attrName instanceof EAttribute) {
			Object nameA = elementA.eGet(attrName);
			Object nameB = elementB.eGet(attrName);

			if (nameA != null && nameB != null) {
				return nameA.equals(nameB);
			}
		}

		return false;
	}

	@Override
	public String getName() {
		return "Simplewebmodel Matcher (Signature)";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public boolean canHandle(Resource modelA, Resource modelB) {
		String docTypeA = EMFModelAccessEx.getCharacteristicDocumentType(modelA);
		String docTypeB = EMFModelAccessEx.getCharacteristicDocumentType(modelB);

		return docTypeA.equals(SimplewebmodelPackage.eNS_URI) && docTypeB.equals(SimplewebmodelPackage.eNS_URI);
	}
}
