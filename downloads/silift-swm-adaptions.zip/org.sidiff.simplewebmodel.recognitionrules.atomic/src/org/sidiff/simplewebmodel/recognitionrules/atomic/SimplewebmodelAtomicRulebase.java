package org.sidiff.simplewebmodel.recognitionrules.atomic;

import org.sidiff.difference.rulebase.extension.AbstractRuleBase;

public class SimplewebmodelAtomicRulebase extends AbstractRuleBase {

	public static final String BUNDLE_ID = "org.sidiff.simplewebmodel.recognitionrules.atomic";
	public static final String RULE_BASE_DIR = "rulebase";
	public static final String RULE_BASE_NAME = "SimplewebmodelAtomic";
	public static final String RULE_BASE_EXT = ".rulebase";
	
	@Override
	protected String getRuleBaseURI() {
		return "/" + BUNDLE_ID + "/" + RULE_BASE_DIR + "/" + RULE_BASE_NAME + RULE_BASE_EXT;
	}
}