package org.sidiff.simplewebmodel.recognitionrules.complex;

import org.sidiff.difference.rulebase.extension.AbstractRuleBase;

public class SimplewebmodelComplexRulebase extends AbstractRuleBase {

	public static final String BUNDLE_ID = "org.sidiff.simplewebmodel.recognitionrules.complex";
	public static final String RULE_BASE_DIR = "rulebase";
	public static final String RULE_BASE_NAME = "SimplewebmodelComplex";
	public static final String RULE_BASE_EXT = ".rulebase";
	
	@Override
	protected String getRuleBaseURI() {
		return "/" + BUNDLE_ID + "/" + RULE_BASE_DIR + "/" + RULE_BASE_NAME + RULE_BASE_EXT;
	}
}